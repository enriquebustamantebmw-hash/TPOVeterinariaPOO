package clinica.modelo;

import clinica.Escenario;
import clinica.excepciones.ReglaNegocioException;
import clinica.excepciones.TurnoNoDisponibleException;
import clinica.modelo.turnos.Agenda;
import clinica.modelo.turnos.Cirugia;
import clinica.modelo.turnos.ConsultaGeneral;
import clinica.modelo.turnos.EstadoTurno;
import clinica.modelo.turnos.Turno;
import clinica.modelo.turnos.Vacunacion;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static clinica.Escenario.HOY;
import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class TurnoTest {
    private Escenario e;
    private Agenda agenda;

    @BeforeEach
    void preparar() {
        e = new Escenario();
        agenda = e.gomez.getAgenda();
    }

    @Test
    void laDuracionDependeDelTipoDeAtencion() {
        assertEquals(30, new ConsultaGeneral().getDuracionMinutos());
        assertEquals(15, new Vacunacion().getDuracionMinutos());
        assertEquals(120, new Cirugia().getDuracionMinutos());
    }

    @Test
    void elFinDelTurnoSeCalculaConLaDuracion() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new Cirugia());
        assertEquals(HOY.atTime(12, 0), t.getFin());
    }

    @Test
    void noSePuedeDarUnTurnoFueraDelHorario() {
        // domingo no atiende y el lunes atiende de 9 a 19
        assertFalse(agenda.estaDisponible(HOY.minusDays(1).atTime(10, 0), new ConsultaGeneral()));
        assertFalse(agenda.estaDisponible(HOY.atTime(8, 30), new ConsultaGeneral()));
        assertFalse(agenda.estaDisponible(HOY.atTime(18, 45), new ConsultaGeneral())); // terminaría 19:15
        assertTrue(agenda.estaDisponible(HOY.atTime(18, 30), new ConsultaGeneral()));
    }

    @Test
    void noSePuedenSuperponerDosTurnosDelMismoVeterinario() throws Exception {
        agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral()); // 10:00 a 10:30
        TurnoNoDisponibleException ex = assertThrows(TurnoNoDisponibleException.class,
                () -> agenda.crearTurno(2, e.michi, HOY.atTime(10, 15), new Vacunacion()));
        assertEquals(HOY.atTime(10, 30), ex.getPrimerHorarioLibre());
        // justo cuando termina el anterior sí se puede
        assertNotNull(agenda.crearTurno(3, e.michi, HOY.atTime(10, 30), new Vacunacion()));
    }

    @Test
    void unTurnoCanceladoLiberaElHorario() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        t.cancelar(HOY.minusDays(1).atTime(10, 0));
        assertTrue(agenda.estaDisponible(LUNES_10, new ConsultaGeneral()));
    }

    @Test
    void cancelarConDosHorasOMasNoTieneCargo() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        assertEquals(0, t.cancelar(HOY.atTime(8, 0)));
        assertEquals(EstadoTurno.CANCELADO, t.getEstado());
    }

    @Test
    void cancelarConMenosDeDosHorasCobraEl20PorCiento() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        assertEquals(ConsultaGeneral.PRECIO * 0.20, t.cancelar(HOY.atTime(8, 1)), 0.001);
    }

    @Test
    void noSePuedeCancelarDosVeces() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        t.cancelar(HOY.atTime(7, 0));
        assertThrows(ReglaNegocioException.class, () -> t.cancelar(HOY.atTime(7, 0)));
    }

    @Test
    void tresAusenciasSeguidasHacenQueElDuenoDebaPagarSena() throws Exception {
        for (int i = 0; i < 3; i++) {
            Turno t = agenda.crearTurno(i + 1, e.firulais, HOY.atTime(10 + i, 0), new ConsultaGeneral());
            assertFalse(e.ana.requiereSena());
            t.marcarAusente(HOY.atTime(18, 0));
        }
        assertEquals(3, e.ana.getAusenciasSeguidas());
        assertTrue(e.ana.requiereSena());
    }

    @Test
    void siVieneAUnTurnoSeReiniciaElContadorDeAusencias() throws Exception {
        Turno t1 = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        Turno t2 = agenda.crearTurno(2, e.firulais, HOY.atTime(11, 0), new ConsultaGeneral());
        t1.marcarAusente(HOY.atTime(12, 0));
        t2.marcarAtendido();
        assertEquals(0, e.ana.getAusenciasSeguidas());
    }

    @Test
    void noSePuedeMarcarAusenteAntesDeLaHora() throws Exception {
        Turno t = agenda.crearTurno(1, e.firulais, LUNES_10, new ConsultaGeneral());
        assertThrows(ReglaNegocioException.class, () -> t.marcarAusente(HOY.atTime(9, 0)));
    }

    @Test
    void losTurnosSeOrdenanPorFecha() throws Exception {
        agenda.crearTurno(1, e.firulais, HOY.atTime(15, 0), new ConsultaGeneral());
        agenda.crearTurno(2, e.michi, HOY.atTime(9, 0), new ConsultaGeneral());
        agenda.crearTurno(3, e.firulais, HOY.atTime(12, 0), new ConsultaGeneral());
        List<Turno> lista = agenda.getTurnos();
        assertEquals(2, lista.get(0).getNumero());
        assertEquals(3, lista.get(1).getNumero());
        assertEquals(1, lista.get(2).getNumero());
    }
}
