package clinica.modelo;

import clinica.Escenario;
import clinica.excepciones.StockInsuficienteException;
import clinica.modelo.historia.NuevaConsulta;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.historia.VacunaAplicada;
import clinica.modelo.mascotas.Especie;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.List;

import static clinica.Escenario.HOY;
import static org.junit.jupiter.api.Assertions.*;

class StockYVacunasTest {

    @Test
    void seConsumePrimeroElLoteQueVenceAntes() throws Exception {
        Insumo gasas = new Insumo("GAS", "Gasas", 1, 100);
        gasas.agregarLote(new Lote("B", HOY.plusDays(90), 5, null));
        gasas.agregarLote(new Lote("A", HOY.plusDays(10), 2, null));
        List<String> usados = gasas.descontar(4, HOY);
        assertEquals(List.of("A", "B"), usados);
        assertEquals(3, gasas.getStockDisponible(HOY));
    }

    @Test
    void unLoteVencidoNoSePuedeUsar() {
        Insumo gasas = new Insumo("GAS", "Gasas", 1, 100);
        gasas.agregarLote(new Lote("VIEJO", HOY.minusDays(1), 10, null));
        assertEquals(10, gasas.getStockActual());
        assertEquals(0, gasas.getStockDisponible(HOY));
        assertThrows(StockInsuficienteException.class, () -> gasas.descontar(1, HOY));
    }

    @Test
    void estaBajoMinimoCuandoLlegaAlValorMinimo() {
        Insumo gasas = new Insumo("GAS", "Gasas", 3, 100);
        gasas.agregarLote(new Lote("A", HOY.plusDays(10), 3, null));
        assertTrue(gasas.estaBajoMinimo(HOY));
    }

    @Test
    void recordatorio7DiasAntesYVencidaA30DiasDelRefuerzo() {
        Escenario e = new Escenario();
        Vacuna vacuna = new Vacuna("Antirrábica", EnumSet.of(Especie.PERRO), 3, 365, "V-ANT");
        LocalDate aplicada = LocalDate.of(2025, 11, 9);
        NuevaConsulta datos = new NuevaConsulta(e.gomez, aplicada.atTime(10, 0), "Vacuna", 18, "Sano", "", null);
        datos.agregarVacuna(vacuna, "L1");
        VacunaAplicada v = e.firulais.getHistoriaClinica().registrarConsulta(datos).getVacunas().get(0);

        LocalDate refuerzo = v.getProximoRefuerzo();
        assertEquals(aplicada.plusDays(365), refuerzo);
        assertFalse(v.estaProximaAVencer(refuerzo.minusDays(8)));
        assertTrue(v.estaProximaAVencer(refuerzo.minusDays(7)));
        assertTrue(v.estaProximaAVencer(refuerzo));
        assertFalse(v.estaVencida(refuerzo.plusDays(30)));
        assertTrue(v.estaVencida(refuerzo.plusDays(31)));
    }

    @Test
    void laVacunaNoSeAplicaAOtraEspecie() {
        Escenario e = new Escenario();
        Vacuna soloGatos = new Vacuna("Triple felina", EnumSet.of(Especie.GATO), 2, 365, "V-TRI");
        assertThrows(clinica.excepciones.VacunaNoAplicableException.class,
                () -> soloGatos.verificarAplicable(e.firulais, HOY));
    }
}
