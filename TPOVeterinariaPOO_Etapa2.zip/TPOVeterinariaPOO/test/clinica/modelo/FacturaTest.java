package clinica.modelo;

import clinica.Escenario;
import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.facturacion.Credito;
import clinica.modelo.facturacion.Debito;
import clinica.modelo.facturacion.EstadoFactura;
import clinica.modelo.facturacion.Efectivo;
import clinica.modelo.facturacion.Factura;
import clinica.modelo.facturacion.NotaCredito;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static clinica.Escenario.HOY;
import static org.junit.jupiter.api.Assertions.*;

class FacturaTest {
    private Escenario e;

    @BeforeEach
    void preparar() {
        e = new Escenario();
    }

    /** Factura de $10.000 de subtotal para el dueño indicado. */
    private Factura facturaDe10000(boolean conPlan) throws ReglaNegocioException {
        if (conPlan) {
            e.ana.adherirAPlan(e.plan);
        }
        Factura f = new Factura(1, HOY, e.ana, 1, 1);
        f.agregarLinea("Consulta", 1, 8000);
        f.agregarLinea("Jeringa", 4, 500);
        return f;
    }

    @Test
    void efectivoTiene10PorCientoDeDescuento() throws Exception {
        Factura f = facturaDe10000(false);
        f.emitir(new Efectivo());
        assertEquals(9000, f.getTotal(), 0.001);
    }

    @Test
    void debitoNoTieneRecargo() throws Exception {
        Factura f = facturaDe10000(false);
        f.emitir(new Debito());
        assertEquals(10000, f.getTotal(), 0.001);
    }

    @Test
    void creditoTiene8PorCientoDeRecargo() throws Exception {
        Factura f = facturaDe10000(false);
        f.emitir(new Credito(3));
        assertEquals(10800, f.getTotal(), 0.001);
    }

    @Test
    void elPlanNoSeAcumulaConEfectivoSeAplicaElMayor() throws Exception {
        Factura f = facturaDe10000(true);
        f.emitir(new Efectivo());
        assertEquals(15, f.getPorcentajeDescuento());
        assertEquals(8500, f.getTotal(), 0.001);
    }

    @Test
    void conPlanYCreditoSeDescuentaYDespuesSeRecarga() throws Exception {
        Factura f = facturaDe10000(true);
        f.emitir(new Credito(6));
        assertEquals(10000 * 0.85 * 1.08, f.getTotal(), 0.001);
    }

    @Test
    void laSenaSeRestaDelTotal() throws Exception {
        Factura f = facturaDe10000(false);
        f.descontarSena(2000);
        f.emitir(new Debito());
        assertEquals(8000, f.getTotal(), 0.001);
    }

    @Test
    void unaFacturaEmitidaNoSeModifica() throws Exception {
        Factura f = facturaDe10000(false);
        f.emitir(new Debito());
        assertThrows(ReglaNegocioException.class, () -> f.agregarLinea("Otra cosa", 1, 100));
        assertThrows(ReglaNegocioException.class, () -> f.emitir(new Efectivo()));
    }

    @Test
    void siHayErrorSeAnulaConNotaDeCredito() throws Exception {
        Factura f = facturaDe10000(false);
        f.emitir(new Debito());
        NotaCredito nota = f.anular(1, HOY, "Se cobró mal la consulta");
        assertEquals(EstadoFactura.ANULADA, f.getEstado());
        assertEquals(10000, nota.getImporte(), 0.001);
        assertThrows(ReglaNegocioException.class, () -> f.anular(2, HOY, "otra vez"));
    }

    @Test
    void noSeEmiteUnaFacturaVacia() {
        Factura f = new Factura(1, HOY, e.ana, 1, 1);
        assertThrows(ReglaNegocioException.class, () -> f.emitir(new Efectivo()));
    }
}
