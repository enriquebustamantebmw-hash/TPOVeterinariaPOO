package clinica.modelo;

import clinica.Escenario;
import clinica.modelo.historia.HistoriaClinica;
import clinica.modelo.historia.NuevaConsulta;
import clinica.modelo.mascotas.Especie;
import clinica.modelo.mascotas.Mascota;
import org.junit.jupiter.api.Test;

import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class MascotaYDuenoTest {

    @Test
    void alTransferirLaMascotaConservaSuHistoriaClinica() {
        Escenario e = new Escenario();
        e.firulais.getHistoriaClinica().registrarConsulta(
                new NuevaConsulta(e.gomez, LUNES_10, "Control", 18, "Sano", "", null));
        HistoriaClinica antes = e.firulais.getHistoriaClinica();

        e.firulais.transferirA(e.juan);

        assertSame(e.juan, e.firulais.getDueno());
        assertTrue(e.juan.getMascotas().contains(e.firulais));
        assertFalse(e.ana.getMascotas().contains(e.firulais));
        assertSame(antes, e.firulais.getHistoriaClinica());
        assertEquals(1, e.firulais.getHistoriaClinica().getConsultas().size());
    }

    @Test
    void unDuenoPuedeTenerVariasMascotas() {
        Escenario e = new Escenario();
        assertEquals(2, e.juan.getMascotas().size());
    }

    @Test
    void cadaEspecieDevuelveSusDatosPropios() {
        Escenario e = new Escenario();
        Mascota perro = e.firulais;
        Mascota gato = e.michi;
        assertEquals(Especie.PERRO, perro.getEspecie());
        assertTrue(perro.getDatosEspecificos().contains("Chip"));
        assertEquals("Vive en interior", gato.getDatosEspecificos());
    }

    @Test
    void soloElVeterinarioPuedeRegistrarDiagnosticos() {
        Escenario e = new Escenario();
        assertTrue(e.gomez.puedeRegistrarDiagnostico());
        assertFalse(e.recepcionista.puedeRegistrarDiagnostico());
    }
}
