package clinica;

import clinica.controladores.ControladorConsultas;
import clinica.controladores.ControladorFacturacion;
import clinica.controladores.ControladorTurnos;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.mascotas.Especie;
import clinica.modelo.mascotas.Gato;
import clinica.modelo.mascotas.Perro;
import clinica.modelo.mascotas.Sexo;
import clinica.modelo.mascotas.Tamanio;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.PlanSalud;
import clinica.modelo.personas.Recepcionista;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import clinica.modelo.stock.Medicamento;
import clinica.persistencia.BaseDeDatos;
import clinica.servicios.Notificador;
import clinica.servicios.ServicioStock;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/** Datos fijos para las pruebas. El "hoy" de las pruebas es el lunes 9/11/2026. */
public class Escenario {
    public static final LocalDate HOY = LocalDate.of(2026, 11, 9); // lunes
    public static final LocalDateTime LUNES_10 = HOY.atTime(10, 0);

    public final BaseDeDatos base = new BaseDeDatos();
    public final List<String> avisos = new ArrayList<>();
    public final Notificador notificador = (destinatario, mensaje) -> avisos.add(destinatario + ": " + mensaje);

    public final Veterinario gomez;
    public final Recepcionista recepcionista;
    public final Dueno ana;
    public final Dueno juan;
    public final Perro firulais;
    public final Gato michi;
    public final Perro cachorro;
    public final PlanSalud plan = new PlanSalud("Plan Salud Animal");

    public final ServicioStock stock;
    public final ControladorTurnos turnos;
    public final ControladorConsultas consultas;
    public final ControladorFacturacion facturacion;

    public Escenario() {
        gomez = new Veterinario("Laura", "Gómez", "30111222", "111", "MP-1", "Clínica");
        for (DayOfWeek dia : EnumSet.range(DayOfWeek.MONDAY, DayOfWeek.SATURDAY)) {
            gomez.definirHorario(dia, LocalTime.of(9, 0), LocalTime.of(19, 0));
        }
        gomez.setDeGuardia(true);
        recepcionista = new Recepcionista("Sofía", "Ruiz", "35123456", "222");
        base.getEmpleados().guardar(gomez);
        base.getEmpleados().guardar(recepcionista);

        base.getPlanes().guardar(plan);
        ana = new Dueno("Ana", "López", "40111222", "333", "ana@mail.com");
        juan = new Dueno("Juan", "Martínez", "38222333", "444", "juan@mail.com");
        base.getDuenos().guardar(ana);
        base.getDuenos().guardar(juan);

        firulais = new Perro(base.siguiente("mascota"), "Firulais", "Mestizo", Sexo.MACHO,
                LocalDate.of(2023, 1, 10), 18, ana, "123", Tamanio.MEDIANO);
        michi = new Gato(base.siguiente("mascota"), "Michi", "Siamés", Sexo.HEMBRA,
                LocalDate.of(2024, 5, 1), 4, juan, true);
        cachorro = new Perro(base.siguiente("mascota"), "Toby", "Caniche", Sexo.MACHO,
                HOY.minusWeeks(5), 1.2, juan, "", Tamanio.CHICO);
        base.getMascotas().guardar(firulais);
        base.getMascotas().guardar(michi);
        base.getMascotas().guardar(cachorro);

        Insumo antirrabica = new Insumo("V-ANT", "Vacuna antirrábica", 2, 8000);
        antirrabica.agregarLote(new Lote("VENCIDO", HOY.minusDays(5), 10, null));
        antirrabica.agregarLote(new Lote("L2", HOY.plusDays(100), 3, null));
        antirrabica.agregarLote(new Lote("L1", HOY.plusDays(30), 2, null));
        Insumo jeringa = new Insumo("JER", "Jeringa", 3, 300);
        jeringa.agregarLote(new Lote("J1", HOY.plusDays(300), 5, null));
        Medicamento amoxicilina = new Medicamento("AMOX", "Amoxicilina", 2, 4500, "Amoxicilina", "Comprimidos");
        amoxicilina.agregarLote(new Lote("A1", HOY.plusDays(200), 10, null));
        base.getInsumos().guardar(antirrabica);
        base.getInsumos().guardar(jeringa);
        base.getInsumos().guardar(amoxicilina);

        base.getVacunas().guardar(new Vacuna("Antirrábica", EnumSet.of(Especie.PERRO, Especie.GATO), 3, 365, "V-ANT"));

        stock = new ServicioStock(base.getInsumos());
        turnos = new ControladorTurnos(base.getTurnos(), base.getDuenos(), base.getMascotas(), base.getEmpleados(),
                notificador, base);
        consultas = new ControladorConsultas(base.getMascotas(), base.getEmpleados(), base.getTurnos(),
                base.getVacunas(), stock);
        facturacion = new ControladorFacturacion(base.getFacturas(), base.getMascotas(), base);
    }
}
