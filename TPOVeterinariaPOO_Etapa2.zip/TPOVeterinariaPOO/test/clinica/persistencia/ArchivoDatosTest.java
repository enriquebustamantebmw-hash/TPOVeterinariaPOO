package clinica.persistencia;

import clinica.Escenario;
import clinica.excepciones.PersistenciaException;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.turnos.ConsultaGeneral;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class ArchivoDatosTest {

    @TempDir
    Path carpeta;

    @Test
    void loQueSeGuardaSePuedeVolverALeer() throws Exception {
        Escenario e = new Escenario();
        e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        ArchivoDatos archivo = new ArchivoDatos(carpeta.resolve("clinica.dat"));

        archivo.guardar(e.base);
        BaseDeDatos leida = archivo.cargar();

        Mascota firulais = leida.getMascotas().buscar("1").orElseThrow();
        assertEquals("Firulais", firulais.getNombre());
        assertEquals("Ana López", firulais.getDueno().getNombreCompleto());
        assertEquals(1, leida.getTurnos().listar().size());
        // el turno guardado también aparece en la agenda del veterinario leído
        assertEquals(1, ((clinica.modelo.personas.Veterinario) leida.getEmpleados().buscar("30111222").orElseThrow())
                .getAgenda().getTurnos().size());
        // los contadores siguen desde donde quedaron
        assertEquals(4, leida.siguiente("mascota"));
    }

    @Test
    void unArchivoRotoTiraPersistenciaException() throws Exception {
        Path roto = carpeta.resolve("roto.dat");
        Files.writeString(roto, "esto no es un objeto serializado");
        assertThrows(PersistenciaException.class, () -> new ArchivoDatos(roto).cargar());
    }
}
