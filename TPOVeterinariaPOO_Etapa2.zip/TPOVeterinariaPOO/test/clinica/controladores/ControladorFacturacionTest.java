package clinica.controladores;

import clinica.Escenario;
import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.facturacion.Debito;
import clinica.modelo.facturacion.Factura;
import clinica.modelo.turnos.ConsultaGeneral;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static clinica.Escenario.HOY;
import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class ControladorFacturacionTest {
    private Escenario e;

    @BeforeEach
    void preparar() {
        e = new Escenario();
    }

    @Test
    void laFacturaIncluyeLaConsultaYLosInsumos() throws Exception {
        DatosConsulta datos = new DatosConsulta("30111222", e.firulais.getNumero(), 0, "Control", 18, "Sano", "")
                .agregarInsumo("JER", 2).agregarVacuna("Antirrábica");
        e.consultas.registrarConsulta(datos, LUNES_10);

        Factura f = e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY);

        assertEquals(3, f.getLineas().size()); // consulta + vacuna + jeringas
        assertEquals(ConsultaGeneral.PRECIO + 8000 + 2 * 300, f.getTotal(), 0.001);
    }

    @Test
    void noSeFacturaDosVecesLaMismaConsulta() throws Exception {
        e.consultas.registrarConsulta(new DatosConsulta("30111222", e.firulais.getNumero(), 0, "Control", 18,
                "Sano", ""), LUNES_10);
        Factura f = e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY);
        assertThrows(ReglaNegocioException.class,
                () -> e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY));
        // anulada con nota de crédito, se puede volver a facturar bien
        e.facturacion.anularFactura(f.getNumero(), "Error", HOY);
        assertNotNull(e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY));
    }

    @Test
    void elCargoPorCancelacionTardiaSeSumaALaProximaFactura() throws Exception {
        var turno = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", HOY.atTime(15, 0), new ConsultaGeneral());
        e.turnos.cancelarTurno(turno.getNumero(), HOY.atTime(14, 0));
        e.consultas.registrarConsulta(new DatosConsulta("30111222", e.firulais.getNumero(), 0, "Control", 18,
                "Sano", ""), LUNES_10);

        Factura f = e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY);
        assertEquals(ConsultaGeneral.PRECIO * 1.2, f.getTotal(), 0.001);
    }

    @Test
    void siSeAnulaLaFacturaElCargoVuelveAQuedarPendiente() throws Exception {
        var turno = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", HOY.atTime(15, 0), new ConsultaGeneral());
        e.turnos.cancelarTurno(turno.getNumero(), HOY.atTime(14, 0));
        e.consultas.registrarConsulta(new DatosConsulta("30111222", e.firulais.getNumero(), 0, "Control", 18,
                "Sano", ""), LUNES_10);
        Factura f = e.facturacion.facturarConsulta(e.firulais.getNumero(), 1, new Debito(), HOY);

        e.facturacion.anularFactura(f.getNumero(), "Error", HOY);

        assertEquals(1, e.ana.tomarCargosPendientes().size());
    }
}
