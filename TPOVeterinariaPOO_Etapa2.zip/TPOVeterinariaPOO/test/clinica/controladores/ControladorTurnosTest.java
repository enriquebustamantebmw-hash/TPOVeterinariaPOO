package clinica.controladores;

import clinica.Escenario;
import clinica.excepciones.SenaRequeridaException;
import clinica.excepciones.TurnoNoDisponibleException;
import clinica.modelo.turnos.ConsultaGeneral;
import clinica.modelo.turnos.EstadoTurno;
import clinica.modelo.turnos.Turno;
import clinica.modelo.turnos.Vacunacion;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static clinica.Escenario.HOY;
import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class ControladorTurnosTest {
    private Escenario e;

    @BeforeEach
    void preparar() {
        e = new Escenario();
    }

    @Test
    void asignarTurnoLoGuardaYAvisaAlDueno() throws Exception {
        Turno t = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        assertEquals(EstadoTurno.PROGRAMADO, t.getEstado());
        assertTrue(e.base.getTurnos().existe(t.getId()));
        assertEquals(1, e.avisos.size());
        assertTrue(e.avisos.get(0).startsWith("ana@mail.com"));
    }

    @Test
    void asignarEnUnHorarioOcupadoTiraExcepcion() throws Exception {
        e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        assertThrows(TurnoNoDisponibleException.class,
                () -> e.turnos.asignarTurno(e.michi.getNumero(), "30111222", LUNES_10, new Vacunacion()));
    }

    @Test
    void conTresAusenciasNoSeDaTurnoSinSena() throws Exception {
        for (int i = 0; i < 3; i++) {
            e.ana.registrarAusencia();
        }
        assertThrows(SenaRequeridaException.class,
                () -> e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral()));

        e.turnos.registrarPagoSena("40111222", 5000);
        Turno t = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        assertEquals(5000, t.getSena());
        // la seña se usó en este turno: para otro turno tiene que volver a pagar
        assertThrows(SenaRequeridaException.class, () -> e.turnos.asignarTurno(e.firulais.getNumero(), "30111222",
                HOY.atTime(12, 0), new ConsultaGeneral()));
    }

    @Test
    void cancelacionTardiaQuedaComoCargoPendiente() throws Exception {
        Turno t = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        double cargo = e.turnos.cancelarTurno(t.getNumero(), HOY.atTime(9, 0));
        assertEquals(5000, cargo, 0.001);
        assertEquals(1, e.ana.tomarCargosPendientes().size());
    }

    @Test
    void laUrgenciaDesplazaAlTurnoQueOcupabaEseHorarioYAvisa() throws Exception {
        Turno normal = e.turnos.asignarTurno(e.michi.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        e.avisos.clear();

        Turno urgencia = e.turnos.registrarUrgencia(e.firulais.getNumero(), LUNES_10);

        assertTrue(urgencia.isUrgencia());
        assertEquals(LUNES_10, urgencia.getInicio());
        assertEquals(HOY.atTime(10, 30), normal.getInicio()); // pasó al primer horario libre
        assertEquals(1, e.avisos.size());
        assertTrue(e.avisos.get(0).contains("urgencia"));
    }

    @Test
    void laUrgenciaSinTurnosEnEseHorarioNoMueveNada() throws Exception {
        Turno otro = e.turnos.asignarTurno(e.michi.getNumero(), "30111222", HOY.atTime(12, 0), new ConsultaGeneral());
        e.turnos.registrarUrgencia(e.firulais.getNumero(), LUNES_10);
        assertEquals(HOY.atTime(12, 0), otro.getInicio());
    }

    @Test
    void reprogramarControlaLaDisponibilidad() throws Exception {
        Turno t1 = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        Turno t2 = e.turnos.asignarTurno(e.michi.getNumero(), "30111222", HOY.atTime(11, 0), new ConsultaGeneral());
        assertThrows(TurnoNoDisponibleException.class, () -> e.turnos.reprogramarTurno(t2.getNumero(), LUNES_10));
        e.turnos.reprogramarTurno(t1.getNumero(), HOY.atTime(10, 15)); // se puede pisar a sí mismo
        assertEquals(HOY.atTime(10, 15), t1.getInicio());
    }
}
