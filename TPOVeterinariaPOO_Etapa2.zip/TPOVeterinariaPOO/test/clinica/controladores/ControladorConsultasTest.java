package clinica.controladores;

import clinica.Escenario;
import clinica.excepciones.PermisoDenegadoException;
import clinica.excepciones.PesoNoRegistradoException;
import clinica.excepciones.StockInsuficienteException;
import clinica.excepciones.VacunaNoAplicableException;
import clinica.modelo.historia.Consulta;
import clinica.modelo.historia.VacunaAplicada;
import clinica.modelo.turnos.ConsultaGeneral;
import clinica.modelo.turnos.EstadoTurno;
import clinica.modelo.turnos.Turno;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static clinica.Escenario.HOY;
import static clinica.Escenario.LUNES_10;
import static org.junit.jupiter.api.Assertions.*;

class ControladorConsultasTest {
    private Escenario e;

    @BeforeEach
    void preparar() {
        e = new Escenario();
    }

    private DatosConsulta consultaDeFirulais(double peso) {
        return new DatosConsulta("30111222", e.firulais.getNumero(), 0, "Tos", peso, "Traqueobronquitis", "");
    }

    @Test
    void laRecepcionistaNoPuedeRegistrarDiagnosticos() {
        DatosConsulta datos = new DatosConsulta("35123456", e.firulais.getNumero(), 0, "Tos", 18, "Algo", "");
        assertThrows(PermisoDenegadoException.class, () -> e.consultas.registrarConsulta(datos, LUNES_10));
        assertTrue(e.firulais.getHistoriaClinica().getConsultas().isEmpty());
    }

    @Test
    void elVeterinarioRegistraLaConsultaEnLaHistoria() throws Exception {
        Consulta c = e.consultas.registrarConsulta(consultaDeFirulais(19.5), LUNES_10);
        assertEquals(1, c.getNumero());
        assertEquals(1, e.firulais.getHistoriaClinica().getConsultas().size());
        assertEquals(19.5, e.firulais.getPeso()); // se actualiza el peso actual
    }

    @Test
    void sinPesoNoSePuedeIndicarMedicamento() {
        DatosConsulta datos = consultaDeFirulais(0).agregarTratamiento("AMOX", "1 comprimido", "cada 12 h", 7);
        assertThrows(PesoNoRegistradoException.class, () -> e.consultas.registrarConsulta(datos, LUNES_10));
    }

    @Test
    void conPesoSeRegistraElTratamientoYNoSeDescuentaElMedicamento() throws Exception {
        DatosConsulta datos = consultaDeFirulais(18).agregarTratamiento("AMOX", "1 comprimido", "cada 12 h", 7);
        Consulta c = e.consultas.registrarConsulta(datos, LUNES_10);
        assertEquals(1, c.getTratamientos().size());
        // el tratamiento es una indicación: el stock se descuenta por los insumos usados, no por la receta
        assertEquals(10, e.stock.buscar("AMOX").getStockDisponible(HOY));
    }

    @Test
    void noSeAplicaUnaVacunaAUnAnimalMenorALaEdadMinima() {
        DatosConsulta datos = new DatosConsulta("30111222", e.cachorro.getNumero(), 0, "Vacuna", 1.3, "Sano", "")
                .agregarVacuna("Antirrábica");
        VacunaNoAplicableException ex = assertThrows(VacunaNoAplicableException.class,
                () -> e.consultas.registrarConsulta(datos, LUNES_10));
        assertTrue(ex.getMessage().contains("edad mínima"));
    }

    @Test
    void laVacunaUsaElLoteQueVencePrimeroYCalculaElRefuerzo() throws Exception {
        DatosConsulta datos = consultaDeFirulais(18).agregarVacuna("Antirrábica");
        Consulta c = e.consultas.registrarConsulta(datos, LUNES_10);
        VacunaAplicada v = c.getVacunas().get(0);
        assertEquals("L1", v.getLote()); // el vencido no se usa; L1 vence antes que L2
        assertEquals(HOY.plusDays(365), v.getProximoRefuerzo());
        assertEquals(4, e.stock.buscar("V-ANT").getStockDisponible(HOY));
    }

    @Test
    void siFaltaStockNoSeRegistraNadaNiSeDescuenta() throws Exception {
        DatosConsulta datos = consultaDeFirulais(18).agregarInsumo("JER", 2).agregarInsumo("V-ANT", 50);
        assertThrows(StockInsuficienteException.class, () -> e.consultas.registrarConsulta(datos, LUNES_10));
        assertEquals(5, e.stock.buscar("JER").getStockDisponible(HOY));
        assertTrue(e.firulais.getHistoriaClinica().getConsultas().isEmpty());
    }

    @Test
    void alLlegarAlMinimoSeAvisaAlObservador() throws Exception {
        List<String> alertas = new ArrayList<>();
        e.stock.suscribir((insumo, disponible) -> alertas.add(insumo.getCodigo() + "=" + disponible));
        e.consultas.registrarConsulta(consultaDeFirulais(18).agregarInsumo("JER", 2), LUNES_10);
        assertEquals(List.of("JER=3"), alertas);
    }

    @Test
    void laConsultaConTurnoDejaElTurnoAtendido() throws Exception {
        Turno t = e.turnos.asignarTurno(e.firulais.getNumero(), "30111222", LUNES_10, new ConsultaGeneral());
        DatosConsulta datos = new DatosConsulta("30111222", e.firulais.getNumero(), t.getNumero(), "Control", 18,
                "Sano", "");
        e.consultas.registrarConsulta(datos, LUNES_10);
        assertEquals(EstadoTurno.ATENDIDO, t.getEstado());
    }

    @Test
    void laHistoriaNoSePuedeModificarDesdeAfuera() throws Exception {
        e.consultas.registrarConsulta(consultaDeFirulais(18), LUNES_10);
        assertThrows(UnsupportedOperationException.class,
                () -> e.firulais.getHistoriaClinica().getConsultas().clear());
    }

    @Test
    void soloUnVeterinarioPuedeAgregarNotaRectificatoria() throws Exception {
        e.consultas.registrarConsulta(consultaDeFirulais(18), LUNES_10);
        assertThrows(PermisoDenegadoException.class, () -> e.consultas.agregarNotaRectificatoria("35123456",
                e.firulais.getNumero(), 1, "Corrección", LUNES_10));
        e.consultas.agregarNotaRectificatoria("30111222", e.firulais.getNumero(), 1, "El peso era 18,5", LUNES_10);
        assertEquals(1, e.firulais.getHistoriaClinica().getNotas().size());
        assertEquals(1, e.firulais.getHistoriaClinica().getConsultas().size()); // la consulta original sigue igual
    }
}
