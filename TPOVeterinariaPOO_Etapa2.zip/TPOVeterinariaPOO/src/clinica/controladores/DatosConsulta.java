package clinica.controladores;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Lo que se carga en pantalla para registrar una consulta (todavía sin validar). */
public class DatosConsulta {
    private final String dniProfesional;
    private final int numeroMascota;
    private final int numeroTurno; // 0 si la consulta no viene de un turno
    private final String motivo;
    private final double peso;     // 0 si no se pesó al animal
    private final String diagnostico;
    private final String observaciones;
    private final List<String[]> tratamientos = new ArrayList<>();
    private final List<String> vacunas = new ArrayList<>();
    private final Map<String, Integer> insumos = new LinkedHashMap<>();

    public DatosConsulta(String dniProfesional, int numeroMascota, int numeroTurno, String motivo, double peso,
                         String diagnostico, String observaciones) {
        this.dniProfesional = dniProfesional;
        this.numeroMascota = numeroMascota;
        this.numeroTurno = numeroTurno;
        this.motivo = motivo;
        this.peso = peso;
        this.diagnostico = diagnostico;
        this.observaciones = observaciones;
    }

    public DatosConsulta agregarTratamiento(String codigoMedicamento, String dosis, String frecuencia, int dias) {
        tratamientos.add(new String[]{codigoMedicamento, dosis, frecuencia, String.valueOf(dias)});
        return this;
    }

    public DatosConsulta agregarVacuna(String nombreVacuna) {
        vacunas.add(nombreVacuna);
        return this;
    }

    public DatosConsulta agregarInsumo(String codigo, int cantidad) {
        insumos.merge(codigo.trim().toUpperCase(), cantidad, Integer::sum);
        return this;
    }

    public String getDniProfesional() {
        return dniProfesional;
    }

    public int getNumeroMascota() {
        return numeroMascota;
    }

    public int getNumeroTurno() {
        return numeroTurno;
    }

    public String getMotivo() {
        return motivo;
    }

    public double getPeso() {
        return peso;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public List<String[]> getTratamientos() {
        return tratamientos;
    }

    public List<String> getVacunas() {
        return vacunas;
    }

    public Map<String, Integer> getInsumos() {
        return insumos;
    }
}
