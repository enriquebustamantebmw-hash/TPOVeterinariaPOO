package clinica.controladores;

import clinica.excepciones.ClinicaException;
import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.ReglaNegocioException;
import clinica.excepciones.SenaRequeridaException;
import clinica.excepciones.TurnoNoDisponibleException;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.Empleado;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.turnos.Agenda;
import clinica.modelo.turnos.TipoAtencion;
import clinica.modelo.turnos.Turno;
import clinica.persistencia.Numerador;
import clinica.persistencia.Repositorio;
import clinica.servicios.Notificador;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** CU04 a CU08: asignar, reprogramar y cancelar turnos, urgencias y ausencias. */
public class ControladorTurnos {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Repositorio<Turno> turnos;
    private final Repositorio<Dueno> duenos;
    private final Repositorio<Mascota> mascotas;
    private final Repositorio<Empleado> empleados;
    private final Notificador notificador;
    private final Numerador numerador;

    public ControladorTurnos(Repositorio<Turno> turnos, Repositorio<Dueno> duenos, Repositorio<Mascota> mascotas,
                             Repositorio<Empleado> empleados, Notificador notificador, Numerador numerador) {
        this.turnos = turnos;
        this.duenos = duenos;
        this.mascotas = mascotas;
        this.empleados = empleados;
        this.notificador = notificador;
        this.numerador = numerador;
    }

    public Turno asignarTurno(int numeroMascota, String dniVeterinario, LocalDateTime inicio, TipoAtencion tipo)
            throws ClinicaException {
        Mascota mascota = buscarMascota(numeroMascota);
        Dueno dueno = mascota.getDueno();
        if (dueno.requiereSena() && !dueno.tieneSenaDisponible()) {
            throw new SenaRequeridaException(dueno.getNombreCompleto(), dueno.getAusenciasSeguidas());
        }
        Veterinario veterinario = buscarVeterinario(dniVeterinario);
        Agenda agenda = veterinario.getAgenda();
        // se controla antes de pedir el número para no "gastar" números en intentos fallidos
        if (!agenda.estaDisponible(inicio, tipo)) {
            throw new TurnoNoDisponibleException(inicio, agenda.primerHorarioLibre(inicio, tipo, null));
        }
        Turno turno = agenda.crearTurno(numerador.siguiente("turno"), mascota, inicio, tipo);
        if (dueno.requiereSena()) {
            turno.registrarSena(dueno.usarSena());
        }
        turnos.guardar(turno);
        notificador.enviar(dueno.getEmail(), "Turno confirmado para " + mascota.getNombre() + " el "
                + inicio.format(FORMATO) + " con " + veterinario.getNombreCompleto() + " (" + tipo.getNombre() + ")");
        return turno;
    }

    public void reprogramarTurno(int numeroTurno, LocalDateTime nuevoInicio) throws ClinicaException {
        Turno turno = buscarTurno(numeroTurno);
        turno.getVeterinario().getAgenda().reprogramar(turno, nuevoInicio);
        notificador.enviar(turno.getMascota().getDueno().getEmail(), "El turno de " + turno.getMascota().getNombre()
                + " se pasó al " + nuevoInicio.format(FORMATO));
    }

    /** @return el cargo que se le suma al dueño (0 si canceló con más de 2 horas). */
    public double cancelarTurno(int numeroTurno, LocalDateTime ahora) throws ClinicaException {
        Turno turno = buscarTurno(numeroTurno);
        double cargo = turno.cancelar(ahora);
        Dueno dueno = turno.getMascota().getDueno();
        if (cargo > 0) {
            dueno.agregarCargoPendiente("Cancelación tardía del turno #" + turno.getNumero(), cargo);
        }
        notificador.enviar(dueno.getEmail(), "Se canceló el turno del " + turno.getInicio().format(FORMATO)
                + (cargo > 0 ? String.format(". Por cancelar con menos de 2 horas se cobrarán $%,.2f", cargo) : ""));
        return cargo;
    }

    /**
     * La urgencia toma el primer horario del veterinario de guardia (ahora).
     * Si ese horario estaba ocupado, los turnos que se pisan se pasan al primer lugar libre y se avisa al dueño.
     */
    public Turno registrarUrgencia(int numeroMascota, LocalDateTime ahora) throws ClinicaException {
        Mascota mascota = buscarMascota(numeroMascota);
        Veterinario guardia = buscarVeterinarioDeGuardia();
        Agenda agenda = guardia.getAgenda();

        Turno urgencia = agenda.crearUrgencia(numerador.siguiente("turno"), mascota, ahora.withSecond(0).withNano(0));
        turnos.guardar(urgencia);

        for (Turno desplazado : agenda.turnosQueSeSuperponen(urgencia.getInicio(), urgencia.getFin(), urgencia)) {
            LocalDateTime nuevo = agenda.primerHorarioLibre(urgencia.getFin(), desplazado.getTipo(), desplazado);
            Dueno dueno = desplazado.getMascota().getDueno();
            if (nuevo == null) {
                notificador.enviar(dueno.getEmail(), "Por una urgencia no podemos atender a "
                        + desplazado.getMascota().getNombre() + " en su horario. Comuníquese con la clínica.");
                continue;
            }
            agenda.reprogramar(desplazado, nuevo);
            notificador.enviar(dueno.getEmail(), "Por una urgencia, el turno de " + desplazado.getMascota().getNombre()
                    + " se reprogramó para el " + nuevo.format(FORMATO));
        }
        return urgencia;
    }

    public void registrarAusencia(int numeroTurno, LocalDateTime ahora) throws ClinicaException {
        Turno turno = buscarTurno(numeroTurno);
        turno.marcarAusente(ahora);
        Dueno dueno = turno.getMascota().getDueno();
        if (dueno.requiereSena()) {
            notificador.enviar(dueno.getEmail(), "Registramos " + dueno.getAusenciasSeguidas()
                    + " ausencias seguidas. Para pedir un nuevo turno deberá abonar una seña.");
        }
    }

    public void registrarPagoSena(String dniDueno, double monto) throws NoEncontradoException {
        Dueno dueno = duenos.buscar(dniDueno.trim())
                .orElseThrow(() -> new NoEncontradoException("un dueño con DNI", dniDueno));
        dueno.abonarSena(monto);
    }

    public List<Turno> turnosDeVeterinario(String dni) throws NoEncontradoException {
        return buscarVeterinario(dni).getAgenda().getTurnos();
    }

    public LocalDateTime primerHorarioLibre(String dniVeterinario, LocalDateTime desde, TipoAtencion tipo)
            throws NoEncontradoException {
        return buscarVeterinario(dniVeterinario).getAgenda().primerHorarioLibre(desde, tipo, null);
    }

    public List<Veterinario> listarVeterinarios() {
        List<Veterinario> lista = new ArrayList<>();
        for (Empleado e : empleados.listar()) {
            if (e instanceof Veterinario) {
                lista.add((Veterinario) e);
            }
        }
        return lista;
    }

    public Turno buscarTurno(int numero) throws NoEncontradoException {
        return turnos.buscar(String.valueOf(numero)).orElseThrow(() -> new NoEncontradoException("el turno", "#" + numero));
    }

    private Mascota buscarMascota(int numero) throws NoEncontradoException {
        return mascotas.buscar(String.valueOf(numero))
                .orElseThrow(() -> new NoEncontradoException("la mascota", "#" + numero));
    }

    private Veterinario buscarVeterinario(String dni) throws NoEncontradoException {
        Empleado empleado = empleados.buscar(dni.trim()).orElse(null);
        if (!(empleado instanceof Veterinario)) {
            throw new NoEncontradoException("un veterinario con DNI", dni);
        }
        return (Veterinario) empleado;
    }

    private Veterinario buscarVeterinarioDeGuardia() throws ReglaNegocioException {
        for (Veterinario v : listarVeterinarios()) {
            if (v.isDeGuardia()) {
                return v;
            }
        }
        throw new ReglaNegocioException("No hay ningún veterinario de guardia asignado");
    }
}
