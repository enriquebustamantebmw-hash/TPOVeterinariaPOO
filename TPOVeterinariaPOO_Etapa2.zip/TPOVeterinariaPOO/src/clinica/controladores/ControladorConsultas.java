package clinica.controladores;

import clinica.excepciones.ClinicaException;
import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.PermisoDenegadoException;
import clinica.excepciones.PesoNoRegistradoException;
import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.historia.Consulta;
import clinica.modelo.historia.HistoriaClinica;
import clinica.modelo.historia.InsumoUtilizado;
import clinica.modelo.historia.NotaRectificatoria;
import clinica.modelo.historia.NuevaConsulta;
import clinica.modelo.historia.Tratamiento;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.Empleado;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Medicamento;
import clinica.modelo.turnos.Turno;
import clinica.persistencia.Repositorio;
import clinica.servicios.ServicioStock;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** CU09 Registrar consulta y CU10 Consultar historia clínica. */
public class ControladorConsultas {
    private final Repositorio<Mascota> mascotas;
    private final Repositorio<Empleado> empleados;
    private final Repositorio<Turno> turnos;
    private final Repositorio<Vacuna> vacunas;
    private final ServicioStock servicioStock;

    public ControladorConsultas(Repositorio<Mascota> mascotas, Repositorio<Empleado> empleados,
                                Repositorio<Turno> turnos, Repositorio<Vacuna> vacunas, ServicioStock servicioStock) {
        this.mascotas = mascotas;
        this.empleados = empleados;
        this.turnos = turnos;
        this.vacunas = vacunas;
        this.servicioStock = servicioStock;
    }

    /**
     * Primero se valida todo (permiso, peso, vacunas y stock) y recién después se descuenta el stock
     * y se agrega la consulta a la historia clínica. Así, si algo falla, no queda nada a medias.
     */
    public Consulta registrarConsulta(DatosConsulta datos, LocalDateTime fecha) throws ClinicaException {
        Veterinario veterinario = verificarVeterinario(datos.getDniProfesional());
        Mascota mascota = buscarMascota(datos.getNumeroMascota());
        LocalDate dia = fecha.toLocalDate();

        Turno turno = null;
        if (datos.getNumeroTurno() > 0) {
            turno = turnos.buscar(String.valueOf(datos.getNumeroTurno()))
                    .orElseThrow(() -> new NoEncontradoException("el turno", "#" + datos.getNumeroTurno()));
            if (turno.getMascota() != mascota) {
                throw new ReglaNegocioException("El turno #" + turno.getNumero() + " es de otra mascota");
            }
        }

        // la dosis depende del peso: sin peso no se puede indicar medicamento
        if (!datos.getTratamientos().isEmpty() && datos.getPeso() <= 0) {
            throw new PesoNoRegistradoException();
        }
        List<Tratamiento> tratamientos = new ArrayList<>();
        for (String[] t : datos.getTratamientos()) {
            Insumo producto = servicioStock.buscar(t[0]);
            if (!(producto instanceof Medicamento)) {
                throw new ReglaNegocioException(producto.getNombre() + " no es un medicamento");
            }
            tratamientos.add(new Tratamiento((Medicamento) producto, t[1], t[2], Integer.parseInt(t[3])));
        }

        List<Vacuna> vacunasAAplicar = new ArrayList<>();
        Map<String, Integer> pedidoStock = new LinkedHashMap<>(datos.getInsumos());
        for (String nombre : datos.getVacunas()) {
            Vacuna vacuna = vacunas.buscar(nombre).orElseThrow(() -> new NoEncontradoException("la vacuna", nombre));
            vacuna.verificarAplicable(mascota, dia);
            vacunasAAplicar.add(vacuna);
            pedidoStock.merge(vacuna.getCodigoProducto(), 1, Integer::sum);
        }
        servicioStock.verificarDisponibilidad(pedidoStock, dia);

        // --- a partir de acá ya está todo validado: se confirma la consulta ---
        NuevaConsulta nueva = new NuevaConsulta(veterinario, fecha, datos.getMotivo(), datos.getPeso(),
                datos.getDiagnostico(), datos.getObservaciones(), turno);
        for (Tratamiento t : tratamientos) {
            nueva.agregarTratamiento(t);
        }
        for (Vacuna vacuna : vacunasAAplicar) {
            List<String> lotes = servicioStock.consumir(vacuna.getCodigoProducto(), 1, dia);
            nueva.agregarVacuna(vacuna, lotes.get(0));
            nueva.agregarInsumo(new InsumoUtilizado(servicioStock.buscar(vacuna.getCodigoProducto()), 1, lotes));
        }
        for (Map.Entry<String, Integer> item : datos.getInsumos().entrySet()) {
            List<String> lotes = servicioStock.consumir(item.getKey(), item.getValue(), dia);
            nueva.agregarInsumo(new InsumoUtilizado(servicioStock.buscar(item.getKey()), item.getValue(), lotes));
        }

        Consulta consulta = mascota.getHistoriaClinica().registrarConsulta(nueva);
        if (datos.getPeso() > 0) {
            mascota.actualizarPeso(datos.getPeso());
        }
        if (turno != null) {
            turno.marcarAtendido();
        }
        return consulta;
    }

    public NotaRectificatoria agregarNotaRectificatoria(String dniProfesional, int numeroMascota, int numeroConsulta,
                                                        String texto, LocalDateTime fecha) throws ClinicaException {
        Veterinario veterinario = verificarVeterinario(dniProfesional);
        return buscarMascota(numeroMascota).getHistoriaClinica()
                .agregarNotaRectificatoria(numeroConsulta, veterinario, fecha, texto);
    }

    public HistoriaClinica consultarHistoria(int numeroMascota) throws NoEncontradoException {
        return buscarMascota(numeroMascota).getHistoriaClinica();
    }

    public List<Vacuna> listarVacunas() {
        return vacunas.listar();
    }

    /** RN: solo un veterinario puede registrar diagnósticos y tratamientos. */
    private Veterinario verificarVeterinario(String dni) throws ClinicaException {
        Empleado empleado = empleados.buscar(dni.trim())
                .orElseThrow(() -> new NoEncontradoException("un empleado con DNI", dni));
        if (!empleado.puedeRegistrarDiagnostico()) {
            throw new PermisoDenegadoException(empleado.getNombreCompleto() + " (" + empleado.getRol()
                    + ") no puede registrar diagnósticos ni tratamientos");
        }
        return (Veterinario) empleado;
    }

    private Mascota buscarMascota(int numero) throws NoEncontradoException {
        return mascotas.buscar(String.valueOf(numero))
                .orElseThrow(() -> new NoEncontradoException("la mascota", "#" + numero));
    }
}
