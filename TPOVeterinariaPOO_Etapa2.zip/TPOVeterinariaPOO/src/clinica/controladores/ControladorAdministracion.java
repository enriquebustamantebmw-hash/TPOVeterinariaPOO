package clinica.controladores;

import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.PersistenciaException;
import clinica.modelo.personas.Empleado;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import clinica.modelo.stock.Proveedor;
import clinica.modelo.turnos.Turno;
import clinica.persistencia.Repositorio;
import clinica.servicios.ServicioRecordatorios;
import clinica.servicios.ServicioStock;
import clinica.servicios.VacunaPorVencer;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Consultas del administrador (turnos, stock bajo, vacunas), stock, horarios, guardia y CU13. */
public class ControladorAdministracion {
    private final Repositorio<Empleado> empleados;
    private final Repositorio<Proveedor> proveedores;
    private final ServicioStock servicioStock;
    private final ServicioRecordatorios servicioRecordatorios;

    public ControladorAdministracion(Repositorio<Empleado> empleados, Repositorio<Proveedor> proveedores,
                                     ServicioStock servicioStock, ServicioRecordatorios servicioRecordatorios) {
        this.empleados = empleados;
        this.proveedores = proveedores;
        this.servicioStock = servicioStock;
        this.servicioRecordatorios = servicioRecordatorios;
    }

    public List<Veterinario> listarVeterinarios() {
        List<Veterinario> lista = new ArrayList<>();
        for (Empleado e : empleados.listar()) {
            if (e instanceof Veterinario) {
                lista.add((Veterinario) e);
            }
        }
        return lista;
    }

    public List<Empleado> listarEmpleados() {
        return empleados.listar();
    }

    public List<Turno> turnosDe(Veterinario veterinario) {
        return veterinario.getAgenda().getTurnos();
    }

    public List<Insumo> productosConStockBajo(LocalDate hoy) {
        return servicioStock.productosConStockBajo(hoy);
    }

    public List<VacunaPorVencer> vacunasProximasAVencer(LocalDate hoy) {
        return servicioRecordatorios.vacunasProximasAVencer(hoy);
    }

    public int emitirRecordatorios(LocalDate hoy) {
        return servicioRecordatorios.emitirRecordatorios(hoy);
    }

    /** Supuesto: hay un solo veterinario de guardia a la vez. */
    public void definirGuardia(String dni) throws NoEncontradoException {
        Veterinario elegido = buscarVeterinario(dni);
        for (Veterinario v : listarVeterinarios()) {
            v.setDeGuardia(v == elegido);
        }
    }

    public void definirHorario(String dni, DayOfWeek dia, LocalTime desde, LocalTime hasta) throws NoEncontradoException {
        buscarVeterinario(dni).definirHorario(dia, desde, hasta);
    }

    public void quitarHorario(String dni, DayOfWeek dia) throws NoEncontradoException {
        buscarVeterinario(dni).quitarHorario(dia);
    }

    public void registrarProducto(Insumo insumo) {
        servicioStock.registrarInsumo(insumo);
    }

    public void ingresarLote(String codigo, String numeroLote, LocalDate vencimiento, int cantidad, String proveedor)
            throws NoEncontradoException {
        Proveedor prov = proveedores.buscar(proveedor).orElse(null);
        if (prov == null) {
            prov = new Proveedor(proveedor, "");
            proveedores.guardar(prov);
        }
        servicioStock.ingresarLote(codigo, new Lote(numeroLote, vencimiento, cantidad, prov));
    }

    public List<Insumo> listarProductos() {
        return servicioStock.listar();
    }

    /** Escribe los tres reportes del administrador en un archivo de texto. */
    public void exportarReporte(Path archivo, LocalDate hoy) throws PersistenciaException {
        PrintWriter out = null;
        try {
            if (archivo.getParent() != null) {
                Files.createDirectories(archivo.getParent());
            }
            out = new PrintWriter(Files.newBufferedWriter(archivo, StandardCharsets.UTF_8));
            out.println("REPORTE CLÍNICA VETERINARIA PATITAS - " + hoy);
            out.println();
            out.println("== Turnos por veterinario ==");
            for (Veterinario v : listarVeterinarios()) {
                out.println(v.getNombreCompleto() + ":");
                for (Turno t : turnosDe(v)) {
                    out.println("   " + t);
                }
            }
            out.println();
            out.println("== Productos con stock bajo ==");
            for (Insumo i : productosConStockBajo(hoy)) {
                out.println("   " + i.getCodigo() + " " + i.getNombre() + ": " + i.getStockDisponible(hoy)
                        + " disponibles (mínimo " + i.getStockMinimo() + ")");
            }
            out.println();
            out.println("== Vacunas próximas a vencer ==");
            for (VacunaPorVencer v : vacunasProximasAVencer(hoy)) {
                out.println("   " + v);
            }
        } catch (IOException e) {
            throw new PersistenciaException("No se pudo escribir el reporte", e);
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

    private Veterinario buscarVeterinario(String dni) throws NoEncontradoException {
        Empleado e = empleados.buscar(dni.trim()).orElse(null);
        if (!(e instanceof Veterinario)) {
            throw new NoEncontradoException("un veterinario con DNI", dni);
        }
        return (Veterinario) e;
    }
}
