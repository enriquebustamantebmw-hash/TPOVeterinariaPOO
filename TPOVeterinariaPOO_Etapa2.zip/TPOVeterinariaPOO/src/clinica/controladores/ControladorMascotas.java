package clinica.controladores;

import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.mascotas.Ave;
import clinica.modelo.mascotas.Conejo;
import clinica.modelo.mascotas.Gato;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.mascotas.Perro;
import clinica.modelo.mascotas.Sexo;
import clinica.modelo.mascotas.Tamanio;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.PlanSalud;
import clinica.persistencia.Numerador;
import clinica.persistencia.Repositorio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/** CU01 Registrar dueño, CU02 Registrar mascota, CU03 Transferir mascota y CU15 Adherir a plan de salud. */
public class ControladorMascotas {
    private final Repositorio<Dueno> duenos;
    private final Repositorio<Mascota> mascotas;
    private final Repositorio<PlanSalud> planes;
    private final Numerador numerador;

    public ControladorMascotas(Repositorio<Dueno> duenos, Repositorio<Mascota> mascotas,
                               Repositorio<PlanSalud> planes, Numerador numerador) {
        this.duenos = duenos;
        this.mascotas = mascotas;
        this.planes = planes;
        this.numerador = numerador;
    }

    public Dueno registrarDueno(String nombre, String apellido, String documento, String telefono, String email)
            throws ReglaNegocioException {
        if (duenos.existe(documento.trim())) {
            throw new ReglaNegocioException("Ya hay un dueño registrado con el DNI " + documento);
        }
        Dueno dueno = new Dueno(nombre, apellido, documento, telefono, email);
        duenos.guardar(dueno);
        return dueno;
    }

    public Perro registrarPerro(String dniDueno, String nombre, String raza, Sexo sexo, LocalDate nacimiento,
                                double peso, String chip, Tamanio tamanio) throws NoEncontradoException {
        Perro perro = new Perro(numerador.siguiente("mascota"), nombre, raza, sexo, nacimiento, peso,
                buscarDueno(dniDueno), chip, tamanio);
        mascotas.guardar(perro);
        return perro;
    }

    public Gato registrarGato(String dniDueno, String nombre, String raza, Sexo sexo, LocalDate nacimiento,
                              double peso, boolean interior) throws NoEncontradoException {
        Gato gato = new Gato(numerador.siguiente("mascota"), nombre, raza, sexo, nacimiento, peso,
                buscarDueno(dniDueno), interior);
        mascotas.guardar(gato);
        return gato;
    }

    public Ave registrarAve(String dniDueno, String nombre, String raza, Sexo sexo, LocalDate nacimiento,
                            double peso, boolean puedeVolar) throws NoEncontradoException {
        Ave ave = new Ave(numerador.siguiente("mascota"), nombre, raza, sexo, nacimiento, peso,
                buscarDueno(dniDueno), puedeVolar);
        mascotas.guardar(ave);
        return ave;
    }

    public Conejo registrarConejo(String dniDueno, String nombre, String raza, Sexo sexo, LocalDate nacimiento,
                                  double peso, String pelaje) throws NoEncontradoException {
        Conejo conejo = new Conejo(numerador.siguiente("mascota"), nombre, raza, sexo, nacimiento, peso,
                buscarDueno(dniDueno), pelaje);
        mascotas.guardar(conejo);
        return conejo;
    }

    public void transferirMascota(int numeroMascota, String dniNuevoDueno) throws NoEncontradoException {
        Mascota mascota = buscarMascota(numeroMascota);
        mascota.transferirA(buscarDueno(dniNuevoDueno));
    }

    public void adherirAPlan(String dniDueno, String nombrePlan) throws NoEncontradoException {
        PlanSalud plan = planes.buscar(nombrePlan).orElseThrow(() -> new NoEncontradoException("el plan", nombrePlan));
        buscarDueno(dniDueno).adherirAPlan(plan);
    }

    public void quitarPlan(String dniDueno) throws NoEncontradoException {
        buscarDueno(dniDueno).quitarPlan();
    }

    public Dueno buscarDueno(String dni) throws NoEncontradoException {
        return duenos.buscar(dni.trim()).orElseThrow(() -> new NoEncontradoException("un dueño con DNI", dni));
    }

    public Mascota buscarMascota(int numero) throws NoEncontradoException {
        return mascotas.buscar(String.valueOf(numero))
                .orElseThrow(() -> new NoEncontradoException("la mascota", "#" + numero));
    }

    public List<Dueno> listarDuenos() {
        List<Dueno> lista = duenos.listar();
        lista.sort(Comparator.comparing(Dueno::getApellido).thenComparing(Dueno::getNombre));
        return lista;
    }

    /** Mascotas ordenadas por nombre (Comparator, el orden natural no hace falta acá). */
    public List<Mascota> listarMascotas() {
        List<Mascota> lista = mascotas.listar();
        lista.sort(Comparator.comparing(Mascota::getNombre, String.CASE_INSENSITIVE_ORDER));
        return lista;
    }

    public List<PlanSalud> listarPlanes() {
        return planes.listar();
    }
}
