package clinica.controladores;

import clinica.excepciones.ClinicaException;
import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.facturacion.EstadoFactura;
import clinica.modelo.facturacion.Factura;
import clinica.modelo.facturacion.MedioPago;
import clinica.modelo.facturacion.NotaCredito;
import clinica.modelo.historia.Consulta;
import clinica.modelo.historia.InsumoUtilizado;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.CargoPendiente;
import clinica.modelo.personas.Dueno;
import clinica.persistencia.Numerador;
import clinica.persistencia.Repositorio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/** CU12 Facturar atención y anulación con nota de crédito. */
public class ControladorFacturacion {
    private final Repositorio<Factura> facturas;
    private final Repositorio<Mascota> mascotas;
    private final Numerador numerador;

    public ControladorFacturacion(Repositorio<Factura> facturas, Repositorio<Mascota> mascotas, Numerador numerador) {
        this.facturas = facturas;
        this.mascotas = mascotas;
        this.numerador = numerador;
    }

    /** La factura incluye la atención, los insumos usados y los cargos pendientes del dueño. */
    public Factura facturarConsulta(int numeroMascota, int numeroConsulta, MedioPago medio, LocalDate fecha)
            throws ClinicaException {
        Mascota mascota = mascotas.buscar(String.valueOf(numeroMascota))
                .orElseThrow(() -> new NoEncontradoException("la mascota", "#" + numeroMascota));
        Consulta consulta = mascota.getHistoriaClinica().buscarConsulta(numeroConsulta)
                .orElseThrow(() -> new NoEncontradoException("la consulta", numeroConsulta));
        if (estaFacturada(numeroMascota, numeroConsulta)) {
            throw new ReglaNegocioException("La consulta " + numeroConsulta + " de " + mascota.getNombre()
                    + " ya tiene una factura emitida");
        }

        Dueno dueno = mascota.getDueno();
        Factura factura = new Factura(numerador.siguiente("factura"), fecha, dueno, numeroMascota, numeroConsulta);
        factura.agregarLinea(consulta.getDescripcionAtencion() + " - " + mascota.getNombre(), 1,
                consulta.getPrecioAtencion());
        for (InsumoUtilizado insumo : consulta.getInsumos()) {
            factura.agregarLinea(insumo.getInsumo().getNombre(), insumo.getCantidad(), insumo.getPrecioUnitario());
        }
        for (CargoPendiente cargo : dueno.tomarCargosPendientes()) {
            factura.agregarCargo(cargo);
        }
        if (consulta.getTurno() != null && consulta.getTurno().getSena() > 0) {
            factura.descontarSena(consulta.getTurno().getSena());
        }
        factura.emitir(medio);
        facturas.guardar(factura);
        return factura;
    }

    public NotaCredito anularFactura(int numeroFactura, String motivo, LocalDate fecha) throws ClinicaException {
        Factura factura = facturas.buscar(String.valueOf(numeroFactura))
                .orElseThrow(() -> new NoEncontradoException("la factura", numeroFactura));
        NotaCredito nota = factura.anular(numerador.siguiente("notaCredito"), fecha, motivo);
        // los cargos que estaban en la factura anulada vuelven a quedar pendientes
        for (CargoPendiente cargo : factura.getCargosIncluidos()) {
            factura.getDueno().agregarCargoPendiente(cargo.getConcepto(), cargo.getMonto());
        }
        return nota;
    }

    public List<Factura> listarFacturas() {
        List<Factura> lista = facturas.listar();
        lista.sort(Comparator.comparingInt(Factura::getNumero));
        return lista;
    }

    private boolean estaFacturada(int numeroMascota, int numeroConsulta) {
        for (Factura f : facturas.listar()) {
            if (f.getNumeroMascota() == numeroMascota && f.getNumeroConsulta() == numeroConsulta
                    && f.getEstado() == EstadoFactura.EMITIDA) {
                return true;
            }
        }
        return false;
    }
}
