package clinica.modelo;

/**
 * Lo implementan las clases que se guardan en un repositorio.
 * El id se usa para buscarlas (DNI, código de producto, número, etc.).
 */
public interface Identificable {
    String getId();
}
