package clinica.modelo.personas;

public abstract class Empleado extends Persona {

    protected Empleado(String nombre, String apellido, String documento, String telefono) {
        super(nombre, apellido, documento, telefono);
    }

    public abstract String getRol();

    /** Por defecto nadie puede cargar diagnósticos ni tratamientos. Solo el veterinario lo redefine. */
    public boolean puedeRegistrarDiagnostico() {
        return false;
    }

    @Override
    public String toString() {
        return getRol() + ": " + super.toString();
    }
}
