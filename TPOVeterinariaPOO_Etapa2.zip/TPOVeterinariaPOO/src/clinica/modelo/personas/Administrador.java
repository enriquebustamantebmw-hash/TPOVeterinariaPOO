package clinica.modelo.personas;

public class Administrador extends Empleado {

    public Administrador(String nombre, String apellido, String documento, String telefono) {
        super(nombre, apellido, documento, telefono);
    }

    @Override
    public String getRol() {
        return "Administrador";
    }
}
