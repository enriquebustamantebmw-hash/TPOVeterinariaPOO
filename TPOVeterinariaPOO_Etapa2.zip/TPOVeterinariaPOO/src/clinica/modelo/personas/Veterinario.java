package clinica.modelo.personas;

import clinica.modelo.turnos.Agenda;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class Veterinario extends Empleado {
    private final String matricula;
    private String especialidad;
    private boolean deGuardia;
    // un horario por cada día de la semana en el que atiende
    private final Map<DayOfWeek, HorarioAtencion> horarios = new EnumMap<>(DayOfWeek.class);
    private final Agenda agenda;

    public Veterinario(String nombre, String apellido, String documento, String telefono,
                       String matricula, String especialidad) {
        super(nombre, apellido, documento, telefono);
        this.matricula = matricula;
        this.especialidad = especialidad;
        this.agenda = new Agenda(this);
    }

    @Override
    public String getRol() {
        return "Veterinario";
    }

    @Override
    public boolean puedeRegistrarDiagnostico() {
        return true;
    }

    public void definirHorario(DayOfWeek dia, LocalTime desde, LocalTime hasta) {
        horarios.put(dia, new HorarioAtencion(dia, desde, hasta));
    }

    public void quitarHorario(DayOfWeek dia) {
        horarios.remove(dia);
    }

    public boolean atiendeEn(LocalDateTime inicio, LocalDateTime fin) {
        HorarioAtencion horario = horarios.get(inicio.getDayOfWeek());
        return horario != null && horario.contiene(inicio, fin);
    }

    public List<HorarioAtencion> getHorarios() {
        return new ArrayList<>(horarios.values());
    }

    public Agenda getAgenda() {
        return agenda;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public boolean isDeGuardia() {
        return deGuardia;
    }

    public void setDeGuardia(boolean deGuardia) {
        this.deGuardia = deGuardia;
    }

    @Override
    public String toString() {
        return super.toString() + " - MP " + matricula + " - " + especialidad + (deGuardia ? " [DE GUARDIA]" : "");
    }
}
