package clinica.modelo.personas;

public class Recepcionista extends Empleado {

    public Recepcionista(String nombre, String apellido, String documento, String telefono) {
        super(nombre, apellido, documento, telefono);
    }

    @Override
    public String getRol() {
        return "Recepcionista";
    }
}
