package clinica.modelo.personas;

import clinica.modelo.mascotas.Mascota;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Dueno extends Persona {
    public static final int AUSENCIAS_PARA_SENA = 3;

    private String email;
    private PlanSalud plan;
    private final List<Mascota> mascotas = new ArrayList<>();
    private int ausenciasSeguidas;
    private double senaDisponible;
    private final List<CargoPendiente> cargosPendientes = new ArrayList<>();

    public Dueno(String nombre, String apellido, String documento, String telefono, String email) {
        super(nombre, apellido, documento, telefono);
        this.email = email;
    }

    public void agregarMascota(Mascota mascota) {
        if (!mascotas.contains(mascota)) {
            mascotas.add(mascota);
        }
    }

    public void quitarMascota(Mascota mascota) {
        mascotas.remove(mascota);
    }

    public List<Mascota> getMascotas() {
        return Collections.unmodifiableList(mascotas);
    }

    // ---- plan de salud ----

    public void adherirAPlan(PlanSalud plan) {
        this.plan = plan;
    }

    public void quitarPlan() {
        this.plan = null;
    }

    public boolean tienePlan() {
        return plan != null;
    }

    public PlanSalud getPlan() {
        return plan;
    }

    // ---- ausencias y seña ----

    public void registrarAusencia() {
        ausenciasSeguidas++;
    }

    /** Si vino a un turno, el contador de ausencias seguidas vuelve a cero. */
    public void registrarAsistencia() {
        ausenciasSeguidas = 0;
    }

    public boolean requiereSena() {
        return ausenciasSeguidas >= AUSENCIAS_PARA_SENA;
    }

    public void abonarSena(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("El monto de la seña tiene que ser mayor a cero");
        }
        senaDisponible += monto;
    }

    public boolean tieneSenaDisponible() {
        return senaDisponible > 0;
    }

    /** Usa la seña pagada para el turno que se está dando y la deja en cero. */
    public double usarSena() {
        double monto = senaDisponible;
        senaDisponible = 0;
        return monto;
    }

    public int getAusenciasSeguidas() {
        return ausenciasSeguidas;
    }

    // ---- cargos pendientes ----

    public void agregarCargoPendiente(String concepto, double monto) {
        cargosPendientes.add(new CargoPendiente(concepto, monto));
    }

    /** Devuelve los cargos pendientes y los saca de la lista (se pasan a una factura). */
    public List<CargoPendiente> tomarCargosPendientes() {
        List<CargoPendiente> copia = new ArrayList<>(cargosPendientes);
        cargosPendientes.clear();
        return copia;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
