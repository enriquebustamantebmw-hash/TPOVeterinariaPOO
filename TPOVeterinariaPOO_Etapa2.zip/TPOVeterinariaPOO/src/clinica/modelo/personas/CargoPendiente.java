package clinica.modelo.personas;

import java.io.Serializable;

/** Algo que el dueño debe y se agrega a su próxima factura (por ejemplo, una cancelación tardía). */
public class CargoPendiente implements Serializable {
    private final String concepto;
    private final double monto;

    public CargoPendiente(String concepto, double monto) {
        this.concepto = concepto;
        this.monto = monto;
    }

    public String getConcepto() {
        return concepto;
    }

    public double getMonto() {
        return monto;
    }
}
