package clinica.modelo.personas;

import java.io.Serializable;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;

/** Franja en la que atiende un veterinario un día de la semana. */
public class HorarioAtencion implements Serializable {
    private final DayOfWeek dia;
    private final LocalTime desde;
    private final LocalTime hasta;

    public HorarioAtencion(DayOfWeek dia, LocalTime desde, LocalTime hasta) {
        if (!desde.isBefore(hasta)) {
            throw new IllegalArgumentException("La hora de inicio tiene que ser anterior a la de fin");
        }
        this.dia = dia;
        this.desde = desde;
        this.hasta = hasta;
    }

    /** True si el turno empieza y termina dentro de esta franja (y el mismo día). */
    public boolean contiene(LocalDateTime inicio, LocalDateTime fin) {
        return inicio.getDayOfWeek() == dia
                && inicio.toLocalDate().equals(fin.toLocalDate())
                && !inicio.toLocalTime().isBefore(desde)
                && !fin.toLocalTime().isAfter(hasta);
    }

    public DayOfWeek getDia() {
        return dia;
    }

    public LocalTime getDesde() {
        return desde;
    }

    public LocalTime getHasta() {
        return hasta;
    }

    @Override
    public String toString() {
        return dia.getDisplayName(TextStyle.FULL, Locale.forLanguageTag("es-AR")) + " de " + desde + " a " + hasta;
    }
}
