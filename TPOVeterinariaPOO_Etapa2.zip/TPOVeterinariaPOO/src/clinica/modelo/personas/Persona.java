package clinica.modelo.personas;

import clinica.modelo.Identificable;

import java.io.Serializable;

public abstract class Persona implements Identificable, Serializable {
    protected String nombre;
    protected String apellido;
    protected final String documento;
    protected String telefono;

    protected Persona(String nombre, String apellido, String documento, String telefono) {
        if (documento == null || documento.isBlank()) {
            throw new IllegalArgumentException("El documento es obligatorio");
        }
        if (nombre == null || nombre.isBlank() || apellido == null || apellido.isBlank()) {
            throw new IllegalArgumentException("Nombre y apellido son obligatorios");
        }
        this.nombre = nombre.trim();
        this.apellido = apellido.trim();
        this.documento = documento.trim();
        this.telefono = telefono;
    }

    @Override
    public String getId() {
        return documento;
    }

    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDocumento() {
        return documento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return getNombreCompleto() + " (DNI " + documento + ")";
    }
}
