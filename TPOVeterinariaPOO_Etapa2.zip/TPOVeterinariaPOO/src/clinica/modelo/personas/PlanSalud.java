package clinica.modelo.personas;

import clinica.modelo.Identificable;

import java.io.Serializable;

/** Plan de salud animal al que se puede adherir un dueño. Le da un descuento en las facturas. */
public class PlanSalud implements Identificable, Serializable {
    public static final double DESCUENTO_POR_DEFECTO = 15;

    private final String nombre;
    private final double porcentajeDescuento;

    public PlanSalud(String nombre) {
        this(nombre, DESCUENTO_POR_DEFECTO);
    }

    public PlanSalud(String nombre, double porcentajeDescuento) {
        if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
            throw new IllegalArgumentException("Porcentaje de descuento inválido");
        }
        this.nombre = nombre;
        this.porcentajeDescuento = porcentajeDescuento;
    }

    @Override
    public String getId() {
        return nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPorcentajeDescuento() {
        return porcentajeDescuento;
    }

    @Override
    public String toString() {
        return nombre + " (" + porcentajeDescuento + "% de descuento)";
    }
}
