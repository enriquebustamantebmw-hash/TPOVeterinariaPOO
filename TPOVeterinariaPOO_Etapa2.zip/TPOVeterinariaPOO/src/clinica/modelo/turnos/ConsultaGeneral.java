package clinica.modelo.turnos;

public class ConsultaGeneral extends TipoAtencion {
    public static final double PRECIO = 25000;

    public ConsultaGeneral() {
        super(PRECIO);
    }

    @Override
    public int getDuracionMinutos() {
        return 30;
    }

    @Override
    public String getNombre() {
        return "Consulta general";
    }
}
