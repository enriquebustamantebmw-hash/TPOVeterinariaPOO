package clinica.modelo.turnos;

public class Vacunacion extends TipoAtencion {
    // solo la aplicación; la dosis de la vacuna se cobra aparte como insumo
    public static final double PRECIO = 10000;

    public Vacunacion() {
        super(PRECIO);
    }

    @Override
    public int getDuracionMinutos() {
        return 15;
    }

    @Override
    public String getNombre() {
        return "Vacunación";
    }
}
