package clinica.modelo.turnos;

import java.io.Serializable;

/**
 * Tipo de atención de un turno. Cada subclase define su duración,
 * así no hace falta un switch para saber cuánto dura un turno.
 */
public abstract class TipoAtencion implements Serializable {
    protected final double precio;

    protected TipoAtencion(double precio) {
        this.precio = precio;
    }

    public abstract int getDuracionMinutos();

    public abstract String getNombre();

    public double getPrecio() {
        return precio;
    }

    /** Para elegir el tipo desde el menú: 1 consulta, 2 vacunación, 3 cirugía. */
    public static TipoAtencion desdeOpcion(int opcion) {
        switch (opcion) {
            case 1: return new ConsultaGeneral();
            case 2: return new Vacunacion();
            case 3: return new Cirugia();
            default: throw new IllegalArgumentException("Tipo de atención inválido: " + opcion);
        }
    }

    @Override
    public String toString() {
        return getNombre() + " (" + getDuracionMinutos() + " min)";
    }
}
