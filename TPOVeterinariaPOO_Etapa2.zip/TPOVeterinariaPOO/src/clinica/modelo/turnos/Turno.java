package clinica.modelo.turnos;

import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.Identificable;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.Veterinario;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Turno implements Identificable, Comparable<Turno>, Serializable {
    public static final long MINUTOS_CANCELACION_SIN_CARGO = 120;
    public static final double PORCENTAJE_CANCELACION_TARDIA = 20;
    public static final double RECARGO_URGENCIA = 30;
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final int numero;
    private final Mascota mascota;
    private final Veterinario veterinario;
    private LocalDateTime inicio;
    private final TipoAtencion tipo;
    private final boolean urgencia;
    private EstadoTurno estado;
    private double sena;

    // lo crea la Agenda del veterinario (por eso el constructor no es público)
    Turno(int numero, Mascota mascota, Veterinario veterinario, LocalDateTime inicio,
          TipoAtencion tipo, boolean urgencia) {
        this.numero = numero;
        this.mascota = mascota;
        this.veterinario = veterinario;
        this.inicio = inicio;
        this.tipo = tipo;
        this.urgencia = urgencia;
        this.estado = EstadoTurno.PROGRAMADO;
    }

    public LocalDateTime getFin() {
        return inicio.plusMinutes(tipo.getDuracionMinutos());
    }

    /** Solo los turnos programados ocupan lugar en la agenda. */
    public boolean seSuperponeCon(LocalDateTime otroInicio, LocalDateTime otroFin) {
        return estado == EstadoTurno.PROGRAMADO
                && inicio.isBefore(otroFin)
                && otroInicio.isBefore(getFin());
    }

    public double getPrecio() {
        double precio = tipo.getPrecio();
        if (urgencia) {
            precio = precio * (1 + RECARGO_URGENCIA / 100);
        }
        return precio;
    }

    /**
     * Cancela el turno. Hasta 2 horas antes no tiene cargo,
     * después se cobra el 20% del valor de la atención.
     * @return el cargo a cobrarle al dueño (0 si no corresponde)
     */
    public double cancelar(LocalDateTime ahora) throws ReglaNegocioException {
        verificarProgramado("cancelar");
        estado = EstadoTurno.CANCELADO;
        long minutosAntes = Duration.between(ahora, inicio).toMinutes();
        if (minutosAntes >= MINUTOS_CANCELACION_SIN_CARGO) {
            return 0;
        }
        return getPrecio() * PORCENTAJE_CANCELACION_TARDIA / 100;
    }

    // la disponibilidad la controla la Agenda antes de llamar a este método
    void reprogramar(LocalDateTime nuevoInicio) throws ReglaNegocioException {
        verificarProgramado("reprogramar");
        this.inicio = nuevoInicio;
    }

    public void marcarAusente(LocalDateTime ahora) throws ReglaNegocioException {
        verificarProgramado("marcar como ausente");
        if (ahora.isBefore(inicio)) {
            throw new ReglaNegocioException("Todavía no llegó la hora del turno, no se puede marcar como ausente");
        }
        estado = EstadoTurno.AUSENTE;
        mascota.getDueno().registrarAusencia();
    }

    public void marcarAtendido() throws ReglaNegocioException {
        verificarProgramado("marcar como atendido");
        estado = EstadoTurno.ATENDIDO;
        mascota.getDueno().registrarAsistencia();
    }

    public void registrarSena(double monto) {
        this.sena = monto;
    }

    private void verificarProgramado(String accion) throws ReglaNegocioException {
        if (estado != EstadoTurno.PROGRAMADO) {
            throw new ReglaNegocioException("No se puede " + accion + " el turno #" + numero
                    + " porque está " + estado.toString().toLowerCase());
        }
    }

    // orden natural: por fecha y hora de inicio
    @Override
    public int compareTo(Turno otro) {
        int comparacion = inicio.compareTo(otro.inicio);
        return comparacion != 0 ? comparacion : Integer.compare(numero, otro.numero);
    }

    @Override
    public String getId() {
        return String.valueOf(numero);
    }

    public int getNumero() {
        return numero;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public Veterinario getVeterinario() {
        return veterinario;
    }

    public LocalDateTime getInicio() {
        return inicio;
    }

    public TipoAtencion getTipo() {
        return tipo;
    }

    public boolean isUrgencia() {
        return urgencia;
    }

    public EstadoTurno getEstado() {
        return estado;
    }

    public double getSena() {
        return sena;
    }

    @Override
    public String toString() {
        return "Turno #" + numero + " - " + inicio.format(FORMATO) + " a " + getFin().toLocalTime()
                + " - " + tipo.getNombre() + (urgencia ? " (URGENCIA)" : "")
                + " - " + mascota.getNombre() + " - Dr/a. " + veterinario.getApellido()
                + " - " + estado;
    }
}
