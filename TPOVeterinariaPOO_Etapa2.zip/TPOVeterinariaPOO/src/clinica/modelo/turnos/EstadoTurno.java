package clinica.modelo.turnos;

public enum EstadoTurno {
    PROGRAMADO, ATENDIDO, CANCELADO, AUSENTE
}
