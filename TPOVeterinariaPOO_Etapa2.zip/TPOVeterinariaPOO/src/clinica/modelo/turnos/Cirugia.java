package clinica.modelo.turnos;

public class Cirugia extends TipoAtencion {
    public static final double PRECIO = 150000;
    public static final double USO_QUIROFANO = 30000;

    public Cirugia() {
        super(PRECIO);
    }

    @Override
    public int getDuracionMinutos() {
        return 120;
    }

    @Override
    public String getNombre() {
        return "Cirugía";
    }

    // la cirugía suma el uso del quirófano
    @Override
    public double getPrecio() {
        return precio + USO_QUIROFANO;
    }
}
