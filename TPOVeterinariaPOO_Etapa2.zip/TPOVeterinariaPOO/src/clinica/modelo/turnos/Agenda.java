package clinica.modelo.turnos;

import clinica.excepciones.ReglaNegocioException;
import clinica.excepciones.TurnoNoDisponibleException;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.Veterinario;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Agenda de un veterinario. Sabe qué turnos tiene y si un horario está libre,
 * por eso es la que crea los turnos (Experto y Creador).
 */
public class Agenda implements Serializable {
    private static final int PASO_MINUTOS = 15;
    private static final int DIAS_DE_BUSQUEDA = 60;

    private final Veterinario veterinario;
    private final List<Turno> turnos = new ArrayList<>();

    public Agenda(Veterinario veterinario) {
        this.veterinario = veterinario;
    }

    public boolean estaDisponible(LocalDateTime inicio, TipoAtencion tipo) {
        return estaDisponible(inicio, tipo, null);
    }

    /**
     * El turno tiene que entrar en el horario del veterinario y no pisarse con otro.
     * @param ignorar turno que no se tiene en cuenta (se usa al reprogramar ese mismo turno)
     */
    public boolean estaDisponible(LocalDateTime inicio, TipoAtencion tipo, Turno ignorar) {
        LocalDateTime fin = inicio.plusMinutes(tipo.getDuracionMinutos());
        if (!veterinario.atiendeEn(inicio, fin)) {
            return false;
        }
        return turnosQueSeSuperponen(inicio, fin, ignorar).isEmpty();
    }

    public List<Turno> turnosQueSeSuperponen(LocalDateTime inicio, LocalDateTime fin, Turno ignorar) {
        List<Turno> resultado = new ArrayList<>();
        for (Turno t : turnos) {
            if (t != ignorar && t.seSuperponeCon(inicio, fin)) {
                resultado.add(t);
            }
        }
        Collections.sort(resultado);
        return resultado;
    }

    public Turno crearTurno(int numero, Mascota mascota, LocalDateTime inicio, TipoAtencion tipo)
            throws TurnoNoDisponibleException {
        if (!estaDisponible(inicio, tipo)) {
            throw new TurnoNoDisponibleException(inicio, primerHorarioLibre(inicio, tipo, null));
        }
        Turno turno = new Turno(numero, mascota, veterinario, inicio, tipo, false);
        turnos.add(turno);
        return turno;
    }

    /**
     * La urgencia se atiende en el momento aunque el horario esté ocupado.
     * Los turnos que se pisan los reprograma el controlador.
     */
    public Turno crearUrgencia(int numero, Mascota mascota, LocalDateTime inicio) {
        Turno turno = new Turno(numero, mascota, veterinario, inicio, new ConsultaGeneral(), true);
        turnos.add(turno);
        return turno;
    }

    public void reprogramar(Turno turno, LocalDateTime nuevoInicio) throws ReglaNegocioException {
        if (!turnos.contains(turno)) {
            throw new ReglaNegocioException("El turno no pertenece a esta agenda");
        }
        if (!estaDisponible(nuevoInicio, turno.getTipo(), turno)) {
            throw new TurnoNoDisponibleException(nuevoInicio, primerHorarioLibre(nuevoInicio, turno.getTipo(), turno));
        }
        turno.reprogramar(nuevoInicio);
    }

    /** Busca de a 15 minutos el primer horario libre a partir de una fecha. Devuelve null si no encuentra. */
    public LocalDateTime primerHorarioLibre(LocalDateTime desde, TipoAtencion tipo, Turno ignorar) {
        LocalDateTime candidato = redondearHaciaArriba(desde);
        LocalDateTime limite = desde.plusDays(DIAS_DE_BUSQUEDA);
        while (candidato.isBefore(limite)) {
            if (estaDisponible(candidato, tipo, ignorar)) {
                return candidato;
            }
            candidato = candidato.plusMinutes(PASO_MINUTOS);
        }
        return null;
    }

    private LocalDateTime redondearHaciaArriba(LocalDateTime fecha) {
        LocalDateTime base = fecha.withSecond(0).withNano(0);
        int resto = base.getMinute() % PASO_MINUTOS;
        return resto == 0 ? base : base.plusMinutes(PASO_MINUTOS - resto);
    }

    /** Turnos ordenados por fecha (usa el compareTo de Turno). */
    public List<Turno> getTurnos() {
        List<Turno> copia = new ArrayList<>(turnos);
        Collections.sort(copia);
        return copia;
    }

    public Veterinario getVeterinario() {
        return veterinario;
    }
}
