package clinica.modelo.facturacion;

public enum EstadoFactura {
    BORRADOR, EMITIDA, ANULADA
}
