package clinica.modelo.facturacion;

import java.io.Serializable;
import java.time.LocalDate;

public class NotaCredito implements Serializable {
    private final int numero;
    private final LocalDate fecha;
    private final int numeroFactura;
    private final String motivo;
    private final double importe;

    NotaCredito(int numero, LocalDate fecha, int numeroFactura, String motivo, double importe) {
        this.numero = numero;
        this.fecha = fecha;
        this.numeroFactura = numeroFactura;
        this.motivo = motivo;
        this.importe = importe;
    }

    public int getNumero() {
        return numero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public String getMotivo() {
        return motivo;
    }

    public double getImporte() {
        return importe;
    }

    @Override
    public String toString() {
        return String.format("Nota de crédito %d (%s) - anula la factura %d - $%,.2f - Motivo: %s",
                numero, fecha, numeroFactura, importe, motivo);
    }
}
