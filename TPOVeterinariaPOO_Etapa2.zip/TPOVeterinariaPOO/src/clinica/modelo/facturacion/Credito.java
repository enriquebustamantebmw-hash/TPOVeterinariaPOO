package clinica.modelo.facturacion;

public class Credito implements MedioPago {
    public static final int MAXIMO_CUOTAS = 12;

    private final int cuotas;

    public Credito(int cuotas) {
        if (cuotas < 1 || cuotas > MAXIMO_CUOTAS) {
            throw new IllegalArgumentException("Las cuotas tienen que estar entre 1 y " + MAXIMO_CUOTAS);
        }
        this.cuotas = cuotas;
    }

    @Override
    public String getNombre() {
        return "Crédito en " + cuotas + (cuotas == 1 ? " cuota" : " cuotas");
    }

    @Override
    public double getPorcentajeDescuento() {
        return 0;
    }

    @Override
    public double getPorcentajeRecargo() {
        return 8;
    }

    public int getCuotas() {
        return cuotas;
    }
}
