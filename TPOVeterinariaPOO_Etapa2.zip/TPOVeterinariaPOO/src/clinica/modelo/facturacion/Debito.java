package clinica.modelo.facturacion;

public class Debito implements MedioPago {
    @Override
    public String getNombre() {
        return "Débito";
    }

    @Override
    public double getPorcentajeDescuento() {
        return 0;
    }

    @Override
    public double getPorcentajeRecargo() {
        return 0;
    }
}
