package clinica.modelo.facturacion;

import java.io.Serializable;

public class LineaFactura implements Serializable {
    private final String descripcion;
    private final int cantidad;
    private final double precioUnitario;

    LineaFactura(String descripcion, int cantidad, double precioUnitario) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad tiene que ser mayor a cero");
        }
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotal() {
        return cantidad * precioUnitario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    @Override
    public String toString() {
        return String.format("%-40s %3d x %,12.2f = %,12.2f", descripcion, cantidad, precioUnitario, getSubtotal());
    }
}
