package clinica.modelo.facturacion;

import java.io.Serializable;

/**
 * Cada medio de pago sabe qué descuento o recargo tiene.
 * Para agregar uno nuevo alcanza con una clase más que implemente esta interfaz.
 */
public interface MedioPago extends Serializable {
    String getNombre();

    double getPorcentajeDescuento();

    double getPorcentajeRecargo();
}
