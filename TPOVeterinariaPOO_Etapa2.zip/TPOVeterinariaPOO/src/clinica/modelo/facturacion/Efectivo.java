package clinica.modelo.facturacion;

public class Efectivo implements MedioPago {
    @Override
    public String getNombre() {
        return "Efectivo";
    }

    @Override
    public double getPorcentajeDescuento() {
        return 10;
    }

    @Override
    public double getPorcentajeRecargo() {
        return 0;
    }
}
