package clinica.modelo.facturacion;

import clinica.excepciones.ReglaNegocioException;
import clinica.modelo.Identificable;
import clinica.modelo.personas.CargoPendiente;
import clinica.modelo.personas.Dueno;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Factura de una consulta. Mientras está en borrador se le agregan líneas.
 * Una vez emitida no se modifica más: si hay un error se anula con una nota de crédito.
 */
public class Factura implements Identificable, Serializable {
    private final int numero;
    private final LocalDate fecha;
    private final Dueno dueno;
    private final int numeroMascota;
    private final int numeroConsulta;
    private final List<LineaFactura> lineas = new ArrayList<>();
    private final List<CargoPendiente> cargosIncluidos = new ArrayList<>();
    private double senaACuenta;
    private MedioPago medioPago;
    private double porcentajeDescuento;
    private double porcentajeRecargo;
    private double total;
    private EstadoFactura estado = EstadoFactura.BORRADOR;
    private NotaCredito notaCredito;

    public Factura(int numero, LocalDate fecha, Dueno dueno, int numeroMascota, int numeroConsulta) {
        this.numero = numero;
        this.fecha = fecha;
        this.dueno = dueno;
        this.numeroMascota = numeroMascota;
        this.numeroConsulta = numeroConsulta;
    }

    public void agregarLinea(String descripcion, int cantidad, double precioUnitario) throws ReglaNegocioException {
        verificarBorrador();
        lineas.add(new LineaFactura(descripcion, cantidad, precioUnitario));
    }

    /** Agrega un cargo pendiente del dueño. Se guarda aparte por si después se anula la factura. */
    public void agregarCargo(CargoPendiente cargo) throws ReglaNegocioException {
        agregarLinea(cargo.getConcepto(), 1, cargo.getMonto());
        cargosIncluidos.add(cargo);
    }

    public void descontarSena(double monto) throws ReglaNegocioException {
        verificarBorrador();
        senaACuenta += monto;
    }

    public double calcularSubtotal() {
        double subtotal = 0;
        for (LineaFactura linea : lineas) {
            subtotal += linea.getSubtotal();
        }
        return subtotal;
    }

    /**
     * Calcula el total y deja la factura emitida.
     * El descuento del plan de salud no se suma al de efectivo: se aplica el mayor.
     * El recargo del crédito se aplica sobre el monto ya descontado.
     */
    public void emitir(MedioPago medio) throws ReglaNegocioException {
        verificarBorrador();
        if (lineas.isEmpty()) {
            throw new ReglaNegocioException("No se puede emitir una factura sin líneas");
        }
        this.medioPago = medio;
        double descuentoPlan = dueno.tienePlan() ? dueno.getPlan().getPorcentajeDescuento() : 0;
        porcentajeDescuento = Math.max(medio.getPorcentajeDescuento(), descuentoPlan);
        porcentajeRecargo = medio.getPorcentajeRecargo();

        double conDescuento = calcularSubtotal() * (1 - porcentajeDescuento / 100);
        double conRecargo = conDescuento * (1 + porcentajeRecargo / 100);
        total = redondear(Math.max(0, conRecargo - senaACuenta));
        estado = EstadoFactura.EMITIDA;
    }

    public NotaCredito anular(int numeroNota, LocalDate fechaNota, String motivo) throws ReglaNegocioException {
        if (estado != EstadoFactura.EMITIDA) {
            throw new ReglaNegocioException("Solo se puede anular una factura emitida (la " + numero + " está "
                    + estado.toString().toLowerCase() + ")");
        }
        notaCredito = new NotaCredito(numeroNota, fechaNota, numero, motivo, total);
        estado = EstadoFactura.ANULADA;
        return notaCredito;
    }

    private void verificarBorrador() throws ReglaNegocioException {
        if (estado != EstadoFactura.BORRADOR) {
            throw new ReglaNegocioException("La factura " + numero + " ya fue emitida y no se puede modificar");
        }
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100) / 100.0;
    }

    @Override
    public String getId() {
        return String.valueOf(numero);
    }

    public int getNumero() {
        return numero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public Dueno getDueno() {
        return dueno;
    }

    public int getNumeroMascota() {
        return numeroMascota;
    }

    public int getNumeroConsulta() {
        return numeroConsulta;
    }

    public List<LineaFactura> getLineas() {
        return Collections.unmodifiableList(lineas);
    }

    public List<CargoPendiente> getCargosIncluidos() {
        return Collections.unmodifiableList(cargosIncluidos);
    }

    public MedioPago getMedioPago() {
        return medioPago;
    }

    public double getPorcentajeDescuento() {
        return porcentajeDescuento;
    }

    public double getPorcentajeRecargo() {
        return porcentajeRecargo;
    }

    public double getSenaACuenta() {
        return senaACuenta;
    }

    public double getTotal() {
        return total;
    }

    public EstadoFactura getEstado() {
        return estado;
    }

    public NotaCredito getNotaCredito() {
        return notaCredito;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Factura N° ").append(numero).append(" - ").append(fecha).append(" - ").append(estado).append('\n');
        sb.append("Cliente: ").append(dueno).append('\n');
        for (LineaFactura linea : lineas) {
            sb.append("  ").append(linea).append('\n');
        }
        sb.append(String.format("  Subtotal: $%,.2f%n", calcularSubtotal()));
        if (estado != EstadoFactura.BORRADOR) {
            sb.append("  Medio de pago: ").append(medioPago.getNombre()).append('\n');
            if (porcentajeDescuento > 0) {
                sb.append("  Descuento: ").append(porcentajeDescuento).append("%")
                        .append(dueno.tienePlan() && porcentajeDescuento == dueno.getPlan().getPorcentajeDescuento()
                                ? " (plan de salud)" : " (efectivo)").append('\n');
            }
            if (porcentajeRecargo > 0) {
                sb.append("  Recargo: ").append(porcentajeRecargo).append("%\n");
            }
            if (senaACuenta > 0) {
                sb.append(String.format("  Seña a cuenta: -$%,.2f%n", senaACuenta));
            }
            sb.append(String.format("  TOTAL: $%,.2f%n", total));
        }
        if (notaCredito != null) {
            sb.append("  ").append(notaCredito).append('\n');
        }
        return sb.toString();
    }
}
