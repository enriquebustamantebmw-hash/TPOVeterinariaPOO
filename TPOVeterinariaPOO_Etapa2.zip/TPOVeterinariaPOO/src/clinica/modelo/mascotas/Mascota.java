package clinica.modelo.mascotas;

import clinica.modelo.Identificable;
import clinica.modelo.historia.HistoriaClinica;
import clinica.modelo.personas.Dueno;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class Mascota implements Identificable, Serializable {
    protected final int id;
    protected String nombre;
    protected String raza;
    protected Sexo sexo;
    protected LocalDate fechaNacimiento;
    protected double peso;
    private Dueno dueno;
    private final HistoriaClinica historiaClinica;

    protected Mascota(int id, String nombre, String raza, Sexo sexo, LocalDate fechaNacimiento,
                      double peso, Dueno dueno) {
        if (dueno == null) {
            throw new IllegalArgumentException("Toda mascota tiene que tener un dueño responsable");
        }
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre de la mascota es obligatorio");
        }
        if (fechaNacimiento == null || fechaNacimiento.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Fecha de nacimiento inválida");
        }
        this.id = id;
        this.nombre = nombre.trim();
        this.raza = raza;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.peso = peso;
        this.dueno = dueno;
        this.historiaClinica = new HistoriaClinica();
        dueno.agregarMascota(this);
    }

    public abstract Especie getEspecie();

    /** Datos que dependen de la especie (chip, si vive adentro, si vuela, etc.). */
    public abstract String getDatosEspecificos();

    /**
     * Pasa la mascota a otro dueño. La historia clínica es la misma,
     * así que se conserva todo lo registrado antes.
     */
    public void transferirA(Dueno nuevoDueno) {
        if (nuevoDueno == null || nuevoDueno == dueno) {
            throw new IllegalArgumentException("El nuevo dueño tiene que ser otra persona");
        }
        dueno.quitarMascota(this);
        nuevoDueno.agregarMascota(this);
        dueno = nuevoDueno;
    }

    public int getEdadEnMeses(LocalDate hoy) {
        return (int) ChronoUnit.MONTHS.between(fechaNacimiento, hoy);
    }

    public void actualizarPeso(double nuevoPeso) {
        if (nuevoPeso <= 0) {
            throw new IllegalArgumentException("El peso tiene que ser mayor a cero");
        }
        this.peso = nuevoPeso;
    }

    @Override
    public String getId() {
        return String.valueOf(id);
    }

    public int getNumero() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRaza() {
        return raza;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public double getPeso() {
        return peso;
    }

    public Dueno getDueno() {
        return dueno;
    }

    public HistoriaClinica getHistoriaClinica() {
        return historiaClinica;
    }

    @Override
    public String toString() {
        return "#" + id + " " + nombre + " (" + getEspecie() + ", " + raza + ", " + sexo.toString().toLowerCase()
                + ", " + peso + " kg) - " + getDatosEspecificos() + " - Dueño: " + dueno.getNombreCompleto();
    }
}
