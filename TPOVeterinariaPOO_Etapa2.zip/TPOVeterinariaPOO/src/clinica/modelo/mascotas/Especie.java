package clinica.modelo.mascotas;

public enum Especie {
    PERRO("Perro"), GATO("Gato"), AVE("Ave"), CONEJO("Conejo");

    private final String nombre;

    Especie(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
