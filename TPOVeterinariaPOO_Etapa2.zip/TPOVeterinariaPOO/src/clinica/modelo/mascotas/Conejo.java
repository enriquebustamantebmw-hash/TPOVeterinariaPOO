package clinica.modelo.mascotas;

import clinica.modelo.personas.Dueno;

import java.time.LocalDate;

/** El enunciado no dice qué datos propios tiene el conejo; supusimos el tipo de pelaje. */
public class Conejo extends Mascota {
    private final String tipoPelaje;

    public Conejo(int id, String nombre, String raza, Sexo sexo, LocalDate fechaNacimiento, double peso,
                  Dueno dueno, String tipoPelaje) {
        super(id, nombre, raza, sexo, fechaNacimiento, peso, dueno);
        this.tipoPelaje = tipoPelaje;
    }

    @Override
    public Especie getEspecie() {
        return Especie.CONEJO;
    }

    @Override
    public String getDatosEspecificos() {
        return "Pelaje " + tipoPelaje;
    }

    public String getTipoPelaje() {
        return tipoPelaje;
    }
}
