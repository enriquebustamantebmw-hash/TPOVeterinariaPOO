package clinica.modelo.mascotas;

public enum Tamanio {
    CHICO, MEDIANO, GRANDE
}
