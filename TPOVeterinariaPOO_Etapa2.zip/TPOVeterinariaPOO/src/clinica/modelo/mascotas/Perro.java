package clinica.modelo.mascotas;

import clinica.modelo.personas.Dueno;

import java.time.LocalDate;

public class Perro extends Mascota {
    private final String numeroChip;
    private final Tamanio tamanio;

    public Perro(int id, String nombre, String raza, Sexo sexo, LocalDate fechaNacimiento, double peso,
                 Dueno dueno, String numeroChip, Tamanio tamanio) {
        super(id, nombre, raza, sexo, fechaNacimiento, peso, dueno);
        this.numeroChip = numeroChip;
        this.tamanio = tamanio;
    }

    @Override
    public Especie getEspecie() {
        return Especie.PERRO;
    }

    @Override
    public String getDatosEspecificos() {
        return "Chip: " + (numeroChip == null || numeroChip.isBlank() ? "sin chip" : numeroChip)
                + ", tamaño " + tamanio.toString().toLowerCase();
    }

    public String getNumeroChip() {
        return numeroChip;
    }

    public Tamanio getTamanio() {
        return tamanio;
    }
}
