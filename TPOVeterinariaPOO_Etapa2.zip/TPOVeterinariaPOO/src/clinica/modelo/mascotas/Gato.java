package clinica.modelo.mascotas;

import clinica.modelo.personas.Dueno;

import java.time.LocalDate;

public class Gato extends Mascota {
    private final boolean viveEnInterior;

    public Gato(int id, String nombre, String raza, Sexo sexo, LocalDate fechaNacimiento, double peso,
                Dueno dueno, boolean viveEnInterior) {
        super(id, nombre, raza, sexo, fechaNacimiento, peso, dueno);
        this.viveEnInterior = viveEnInterior;
    }

    @Override
    public Especie getEspecie() {
        return Especie.GATO;
    }

    @Override
    public String getDatosEspecificos() {
        return viveEnInterior ? "Vive en interior" : "Vive en exterior";
    }

    public boolean isViveEnInterior() {
        return viveEnInterior;
    }
}
