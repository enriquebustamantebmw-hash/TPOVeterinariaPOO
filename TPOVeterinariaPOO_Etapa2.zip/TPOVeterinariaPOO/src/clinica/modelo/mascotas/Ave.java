package clinica.modelo.mascotas;

import clinica.modelo.personas.Dueno;

import java.time.LocalDate;

public class Ave extends Mascota {
    private final boolean puedeVolar;

    public Ave(int id, String nombre, String raza, Sexo sexo, LocalDate fechaNacimiento, double peso,
               Dueno dueno, boolean puedeVolar) {
        super(id, nombre, raza, sexo, fechaNacimiento, peso, dueno);
        this.puedeVolar = puedeVolar;
    }

    @Override
    public Especie getEspecie() {
        return Especie.AVE;
    }

    @Override
    public String getDatosEspecificos() {
        return puedeVolar ? "Puede volar" : "No puede volar";
    }

    public boolean isPuedeVolar() {
        return puedeVolar;
    }
}
