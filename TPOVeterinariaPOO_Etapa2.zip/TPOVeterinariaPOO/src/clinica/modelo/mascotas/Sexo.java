package clinica.modelo.mascotas;

public enum Sexo {
    MACHO, HEMBRA
}
