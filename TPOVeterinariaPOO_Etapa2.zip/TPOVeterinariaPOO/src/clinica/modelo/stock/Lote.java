package clinica.modelo.stock;

import java.io.Serializable;
import java.time.LocalDate;

/** Lote de un producto. El orden natural es por fecha de vencimiento (primero el que vence antes). */
public class Lote implements Comparable<Lote>, Serializable {
    private final String numero;
    private final LocalDate vencimiento;
    private final Proveedor proveedor;
    private int cantidad;

    public Lote(String numero, LocalDate vencimiento, int cantidad, Proveedor proveedor) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad del lote tiene que ser mayor a cero");
        }
        this.numero = numero;
        this.vencimiento = vencimiento;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
    }

    public boolean estaVencido(LocalDate hoy) {
        return vencimiento.isBefore(hoy);
    }

    void descontar(int unidades) {
        if (unidades > cantidad) {
            throw new IllegalArgumentException("El lote " + numero + " no tiene tantas unidades");
        }
        cantidad -= unidades;
    }

    @Override
    public int compareTo(Lote otro) {
        int comparacion = vencimiento.compareTo(otro.vencimiento);
        return comparacion != 0 ? comparacion : numero.compareTo(otro.numero);
    }

    public String getNumero() {
        return numero;
    }

    public LocalDate getVencimiento() {
        return vencimiento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    @Override
    public String toString() {
        return "Lote " + numero + " - vence " + vencimiento + " - " + cantidad + " u."
                + (proveedor != null ? " - " + proveedor.getNombre() : "");
    }
}
