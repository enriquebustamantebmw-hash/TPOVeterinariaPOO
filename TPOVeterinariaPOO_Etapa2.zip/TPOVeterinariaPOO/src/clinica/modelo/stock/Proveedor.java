package clinica.modelo.stock;

import clinica.modelo.Identificable;

import java.io.Serializable;

public class Proveedor implements Identificable, Serializable {
    private final String nombre;
    private String telefono;

    public Proveedor(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    @Override
    public String getId() {
        return nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
