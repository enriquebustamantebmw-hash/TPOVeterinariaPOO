package clinica.modelo.stock;

import clinica.excepciones.StockInsuficienteException;
import clinica.modelo.Identificable;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Insumo implements Identificable, Serializable {
    protected final String codigo;
    protected String nombre;
    protected int stockMinimo;
    protected double precio;
    protected final List<Lote> lotes = new ArrayList<>();

    public Insumo(String codigo, String nombre, int stockMinimo, double precio) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El código es obligatorio");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.nombre = nombre;
        this.stockMinimo = stockMinimo;
        this.precio = precio;
    }

    public void agregarLote(Lote lote) {
        lotes.add(lote);
    }

    /** Todo lo que hay en depósito, incluso lo vencido. */
    public int getStockActual() {
        int total = 0;
        for (Lote lote : lotes) {
            total += lote.getCantidad();
        }
        return total;
    }

    /** Lo que se puede usar: los lotes vencidos no cuentan. */
    public int getStockDisponible(LocalDate hoy) {
        int total = 0;
        for (Lote lote : lotes) {
            if (!lote.estaVencido(hoy)) {
                total += lote.getCantidad();
            }
        }
        return total;
    }

    public boolean estaBajoMinimo(LocalDate hoy) {
        return getStockDisponible(hoy) <= stockMinimo;
    }

    /**
     * Descuenta unidades empezando por el lote que vence primero y salteando los vencidos.
     * @return los números de lote que se usaron
     */
    public List<String> descontar(int cantidad, LocalDate hoy) throws StockInsuficienteException {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad tiene que ser mayor a cero");
        }
        int disponible = getStockDisponible(hoy);
        if (disponible < cantidad) {
            throw new StockInsuficienteException(nombre, cantidad, disponible);
        }
        List<Lote> usables = new ArrayList<>();
        for (Lote lote : lotes) {
            if (!lote.estaVencido(hoy) && lote.getCantidad() > 0) {
                usables.add(lote);
            }
        }
        Collections.sort(usables); // por vencimiento (compareTo de Lote)

        List<String> lotesUsados = new ArrayList<>();
        int falta = cantidad;
        for (Lote lote : usables) {
            if (falta == 0) {
                break;
            }
            int tomo = Math.min(falta, lote.getCantidad());
            lote.descontar(tomo);
            falta -= tomo;
            lotesUsados.add(lote.getNumero());
        }
        return lotesUsados;
    }

    public String getTipo() {
        return "Insumo";
    }

    public List<Lote> getLotes() {
        List<Lote> copia = new ArrayList<>(lotes);
        Collections.sort(copia);
        return copia;
    }

    @Override
    public String getId() {
        return codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(int stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "[" + codigo + "] " + nombre + " (" + getTipo() + ") - stock " + getStockActual()
                + " - mínimo " + stockMinimo + " - $" + precio;
    }
}
