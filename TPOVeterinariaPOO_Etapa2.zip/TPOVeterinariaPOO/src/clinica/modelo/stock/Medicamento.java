package clinica.modelo.stock;

public class Medicamento extends Insumo {
    private final String droga;
    private final String presentacion;

    public Medicamento(String codigo, String nombre, int stockMinimo, double precio,
                       String droga, String presentacion) {
        super(codigo, nombre, stockMinimo, precio);
        this.droga = droga;
        this.presentacion = presentacion;
    }

    @Override
    public String getTipo() {
        return "Medicamento";
    }

    public String getDroga() {
        return droga;
    }

    public String getPresentacion() {
        return presentacion;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + droga + ", " + presentacion;
    }
}
