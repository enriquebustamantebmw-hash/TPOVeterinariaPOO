package clinica.modelo.historia;

import clinica.modelo.personas.Veterinario;
import clinica.modelo.turnos.ConsultaGeneral;
import clinica.modelo.turnos.Turno;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Registro de una atención. Una vez creada no se modifica (no tiene setters). */
public class Consulta implements Serializable {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final int numero;
    private final LocalDateTime fecha;
    private final Veterinario veterinario;
    private final String motivo;
    private final double peso;
    private final String diagnostico;
    private final String observaciones;
    private final Turno turno;
    private final List<Tratamiento> tratamientos;
    private final List<VacunaAplicada> vacunas;
    private final List<InsumoUtilizado> insumos;

    Consulta(int numero, NuevaConsulta datos) {
        this.numero = numero;
        this.fecha = datos.fecha;
        this.veterinario = datos.veterinario;
        this.motivo = datos.motivo;
        this.peso = datos.peso;
        this.diagnostico = datos.diagnostico;
        this.observaciones = datos.observaciones;
        this.turno = datos.turno;
        this.tratamientos = new ArrayList<>(datos.tratamientos);
        this.insumos = new ArrayList<>(datos.insumos);
        this.vacunas = new ArrayList<>();
        LocalDate dia = fecha.toLocalDate();
        for (Map.Entry<Vacuna, String> entrada : datos.vacunasConLote.entrySet()) {
            vacunas.add(new VacunaAplicada(entrada.getKey(), dia, entrada.getValue()));
        }
    }

    public boolean tienePesoRegistrado() {
        return peso > 0;
    }

    /** Si vino con turno se cobra el turno; si no, se toma como una consulta general. */
    public double getPrecioAtencion() {
        return turno != null ? turno.getPrecio() : new ConsultaGeneral().getPrecio();
    }

    public String getDescripcionAtencion() {
        if (turno == null) {
            return "Consulta general";
        }
        return turno.getTipo().getNombre() + (turno.isUrgencia() ? " (urgencia)" : "");
    }

    public int getNumero() {
        return numero;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Veterinario getVeterinario() {
        return veterinario;
    }

    public String getMotivo() {
        return motivo;
    }

    public double getPeso() {
        return peso;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public Turno getTurno() {
        return turno;
    }

    public List<Tratamiento> getTratamientos() {
        return Collections.unmodifiableList(tratamientos);
    }

    public List<VacunaAplicada> getVacunas() {
        return Collections.unmodifiableList(vacunas);
    }

    public List<InsumoUtilizado> getInsumos() {
        return Collections.unmodifiableList(insumos);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Consulta ").append(numero).append(" - ").append(fecha.format(FORMATO))
                .append(" - ").append(veterinario.getNombreCompleto()).append('\n')
                .append("   Motivo: ").append(motivo).append('\n')
                .append("   Peso: ").append(tienePesoRegistrado() ? peso + " kg" : "no registrado").append('\n')
                .append("   Diagnóstico: ").append(diagnostico).append('\n');
        if (observaciones != null && !observaciones.isBlank()) {
            sb.append("   Observaciones: ").append(observaciones).append('\n');
        }
        for (Tratamiento t : tratamientos) {
            sb.append("   Tratamiento: ").append(t).append('\n');
        }
        for (VacunaAplicada v : vacunas) {
            sb.append("   Vacuna: ").append(v).append('\n');
        }
        for (InsumoUtilizado i : insumos) {
            sb.append("   Insumo: ").append(i).append('\n');
        }
        return sb.toString();
    }
}
