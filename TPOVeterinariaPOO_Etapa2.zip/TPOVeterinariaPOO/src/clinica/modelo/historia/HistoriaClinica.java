package clinica.modelo.historia;

import clinica.excepciones.NoEncontradoException;
import clinica.modelo.personas.Veterinario;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Historia clínica de una mascota. Solo se le pueden agregar registros:
 * no hay métodos para borrar ni modificar, y las listas se devuelven sin poder cambiarse.
 */
public class HistoriaClinica implements Serializable {
    private final List<Consulta> consultas = new ArrayList<>();
    private final List<NotaRectificatoria> notas = new ArrayList<>();

    public Consulta registrarConsulta(NuevaConsulta datos) {
        Consulta consulta = new Consulta(consultas.size() + 1, datos);
        consultas.add(consulta);
        return consulta;
    }

    public NotaRectificatoria agregarNotaRectificatoria(int numeroConsulta, Veterinario veterinario,
                                                        LocalDateTime fecha, String texto)
            throws NoEncontradoException {
        buscarConsulta(numeroConsulta).orElseThrow(() -> new NoEncontradoException("la consulta", numeroConsulta));
        NotaRectificatoria nota = new NotaRectificatoria(numeroConsulta, veterinario, fecha, texto);
        notas.add(nota);
        return nota;
    }

    public Optional<Consulta> buscarConsulta(int numero) {
        for (Consulta c : consultas) {
            if (c.getNumero() == numero) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }

    public List<Consulta> getConsultas() {
        return Collections.unmodifiableList(consultas);
    }

    public List<NotaRectificatoria> getNotas() {
        return Collections.unmodifiableList(notas);
    }

    public List<VacunaAplicada> getVacunasAplicadas() {
        List<VacunaAplicada> todas = new ArrayList<>();
        for (Consulta c : consultas) {
            todas.addAll(c.getVacunas());
        }
        return todas;
    }

    /** La última aplicación de cada vacuna (las anteriores ya fueron reemplazadas por el refuerzo). */
    public List<VacunaAplicada> getUltimasAplicaciones() {
        Map<String, VacunaAplicada> ultimas = new LinkedHashMap<>();
        for (VacunaAplicada v : getVacunasAplicadas()) {
            VacunaAplicada anterior = ultimas.get(v.getVacuna().getNombre());
            if (anterior == null || !v.getFecha().isBefore(anterior.getFecha())) {
                ultimas.put(v.getVacuna().getNombre(), v);
            }
        }
        return new ArrayList<>(ultimas.values());
    }

    public List<VacunaAplicada> vacunasProximasAVencer(LocalDate hoy) {
        List<VacunaAplicada> resultado = new ArrayList<>();
        for (VacunaAplicada v : getUltimasAplicaciones()) {
            if (v.estaProximaAVencer(hoy)) {
                resultado.add(v);
            }
        }
        return resultado;
    }

    public List<VacunaAplicada> vacunasVencidas(LocalDate hoy) {
        List<VacunaAplicada> resultado = new ArrayList<>();
        for (VacunaAplicada v : getUltimasAplicaciones()) {
            if (v.estaVencida(hoy)) {
                resultado.add(v);
            }
        }
        return resultado;
    }
}
