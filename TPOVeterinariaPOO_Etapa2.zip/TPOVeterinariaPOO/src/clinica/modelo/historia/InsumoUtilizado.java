package clinica.modelo.historia;

import clinica.modelo.stock.Insumo;

import java.io.Serializable;
import java.util.List;

/** Insumo que se usó en una consulta. Guarda el precio del momento para la factura. */
public class InsumoUtilizado implements Serializable {
    private final Insumo insumo;
    private final int cantidad;
    private final double precioUnitario;
    private final String lotes;

    public InsumoUtilizado(Insumo insumo, int cantidad, List<String> lotes) {
        this.insumo = insumo;
        this.cantidad = cantidad;
        this.precioUnitario = insumo.getPrecio();
        this.lotes = String.join(", ", lotes);
    }

    public Insumo getInsumo() {
        return insumo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public String getLotes() {
        return lotes;
    }

    @Override
    public String toString() {
        return insumo.getNombre() + " x" + cantidad + " (lote " + lotes + ")";
    }
}
