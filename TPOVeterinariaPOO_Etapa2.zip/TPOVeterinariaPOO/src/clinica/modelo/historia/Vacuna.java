package clinica.modelo.historia;

import clinica.excepciones.VacunaNoAplicableException;
import clinica.modelo.Identificable;
import clinica.modelo.mascotas.Especie;
import clinica.modelo.mascotas.Mascota;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Set;

/**
 * Vacuna del catálogo. Con las especies a las que se aplica y su intervalo de refuerzo
 * queda armado el calendario de vacunación de cada especie.
 */
public class Vacuna implements Identificable, Serializable {
    private final String nombre;
    private final Set<Especie> especies;
    private final int edadMinimaMeses;
    private final int intervaloRefuerzoDias;
    private final String codigoProducto; // producto del stock que se usa al aplicarla

    public Vacuna(String nombre, Set<Especie> especies, int edadMinimaMeses, int intervaloRefuerzoDias,
                  String codigoProducto) {
        this.nombre = nombre;
        this.especies = EnumSet.copyOf(especies);
        this.edadMinimaMeses = edadMinimaMeses;
        this.intervaloRefuerzoDias = intervaloRefuerzoDias;
        this.codigoProducto = codigoProducto.toUpperCase();
    }

    public void verificarAplicable(Mascota mascota, LocalDate fecha) throws VacunaNoAplicableException {
        if (!especies.contains(mascota.getEspecie())) {
            throw new VacunaNoAplicableException("La vacuna " + nombre + " no es para la especie "
                    + mascota.getEspecie());
        }
        int edad = mascota.getEdadEnMeses(fecha);
        if (edad < edadMinimaMeses) {
            throw new VacunaNoAplicableException(mascota.getNombre() + " tiene " + edad
                    + (edad == 1 ? " mes" : " meses") + " y la edad mínima para " + nombre + " es "
                    + edadMinimaMeses + " meses");
        }
    }

    public LocalDate calcularProximoRefuerzo(LocalDate fechaAplicacion) {
        return fechaAplicacion.plusDays(intervaloRefuerzoDias);
    }

    public boolean seAplicaA(Especie especie) {
        return especies.contains(especie);
    }

    @Override
    public String getId() {
        return nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public Set<Especie> getEspecies() {
        return EnumSet.copyOf(especies);
    }

    public int getEdadMinimaMeses() {
        return edadMinimaMeses;
    }

    public int getIntervaloRefuerzoDias() {
        return intervaloRefuerzoDias;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    @Override
    public String toString() {
        return nombre + " - especies " + especies + " - edad mínima " + edadMinimaMeses
                + " meses - refuerzo cada " + intervaloRefuerzoDias + " días";
    }
}
