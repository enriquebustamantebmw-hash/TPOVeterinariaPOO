package clinica.modelo.historia;

import clinica.modelo.stock.Medicamento;

import java.io.Serializable;

public class Tratamiento implements Serializable {
    private final Medicamento medicamento;
    private final String dosis;
    private final String frecuencia;
    private final int duracionDias;

    public Tratamiento(Medicamento medicamento, String dosis, String frecuencia, int duracionDias) {
        if (medicamento == null) {
            throw new IllegalArgumentException("El tratamiento necesita un medicamento");
        }
        if (duracionDias <= 0) {
            throw new IllegalArgumentException("La duración tiene que ser de al menos un día");
        }
        this.medicamento = medicamento;
        this.dosis = dosis;
        this.frecuencia = frecuencia;
        this.duracionDias = duracionDias;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public String getDosis() {
        return dosis;
    }

    public String getFrecuencia() {
        return frecuencia;
    }

    public int getDuracionDias() {
        return duracionDias;
    }

    @Override
    public String toString() {
        return medicamento.getNombre() + " " + dosis + " " + frecuencia + " durante " + duracionDias + " días";
    }
}
