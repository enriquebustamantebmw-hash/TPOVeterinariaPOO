package clinica.modelo.historia;

import clinica.modelo.personas.Veterinario;
import clinica.modelo.turnos.Turno;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Datos ya validados de una consulta que se va a agregar a la historia clínica.
 * Lo arma el ControladorConsultas y se lo pasa a HistoriaClinica.registrarConsulta.
 */
public class NuevaConsulta {
    Veterinario veterinario;
    LocalDateTime fecha;
    String motivo;
    double peso;
    String diagnostico;
    String observaciones;
    Turno turno;
    final List<Tratamiento> tratamientos = new ArrayList<>();
    final Map<Vacuna, String> vacunasConLote = new LinkedHashMap<>();
    final List<InsumoUtilizado> insumos = new ArrayList<>();

    public NuevaConsulta(Veterinario veterinario, LocalDateTime fecha, String motivo, double peso,
                         String diagnostico, String observaciones, Turno turno) {
        this.veterinario = veterinario;
        this.fecha = fecha;
        this.motivo = motivo;
        this.peso = peso;
        this.diagnostico = diagnostico;
        this.observaciones = observaciones;
        this.turno = turno;
    }

    public void agregarTratamiento(Tratamiento tratamiento) {
        tratamientos.add(tratamiento);
    }

    public void agregarVacuna(Vacuna vacuna, String lote) {
        vacunasConLote.put(vacuna, lote);
    }

    public void agregarInsumo(InsumoUtilizado insumo) {
        insumos.add(insumo);
    }
}
