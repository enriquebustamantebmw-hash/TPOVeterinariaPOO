package clinica.modelo.historia;

import java.io.Serializable;
import java.time.LocalDate;

public class VacunaAplicada implements Serializable {
    public static final int DIAS_DE_AVISO = 7;
    public static final int DIAS_HASTA_VENCER = 30;

    private final Vacuna vacuna;
    private final LocalDate fecha;
    private final String lote;
    private final LocalDate proximoRefuerzo;

    // la crea la HistoriaClinica al registrar la consulta
    VacunaAplicada(Vacuna vacuna, LocalDate fecha, String lote) {
        this.vacuna = vacuna;
        this.fecha = fecha;
        this.lote = lote;
        this.proximoRefuerzo = vacuna.calcularProximoRefuerzo(fecha);
    }

    /** Desde 7 días antes del refuerzo hasta el día del refuerzo se le avisa al dueño. */
    public boolean estaProximaAVencer(LocalDate hoy) {
        return !hoy.isBefore(proximoRefuerzo.minusDays(DIAS_DE_AVISO)) && !hoy.isAfter(proximoRefuerzo);
    }

    /** Pasados 30 días del refuerzo sin aplicarlo, se considera vencida. */
    public boolean estaVencida(LocalDate hoy) {
        return hoy.isAfter(proximoRefuerzo.plusDays(DIAS_HASTA_VENCER));
    }

    public Vacuna getVacuna() {
        return vacuna;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getLote() {
        return lote;
    }

    public LocalDate getProximoRefuerzo() {
        return proximoRefuerzo;
    }

    @Override
    public String toString() {
        return vacuna.getNombre() + " - aplicada el " + fecha + " (lote " + lote + ") - refuerzo: " + proximoRefuerzo;
    }
}
