package clinica.modelo.historia;

import clinica.modelo.personas.Veterinario;

import java.io.Serializable;
import java.time.LocalDateTime;

/** Corrige un error de una consulta sin modificarla. La firma el veterinario que la carga. */
public class NotaRectificatoria implements Serializable {
    private final int numeroConsulta;
    private final Veterinario firmadaPor;
    private final LocalDateTime fecha;
    private final String texto;

    NotaRectificatoria(int numeroConsulta, Veterinario firmadaPor, LocalDateTime fecha, String texto) {
        this.numeroConsulta = numeroConsulta;
        this.firmadaPor = firmadaPor;
        this.fecha = fecha;
        this.texto = texto;
    }

    public int getNumeroConsulta() {
        return numeroConsulta;
    }

    public Veterinario getFirmadaPor() {
        return firmadaPor;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public String getTexto() {
        return texto;
    }

    @Override
    public String toString() {
        return "Nota rectificatoria sobre la consulta " + numeroConsulta + " (" + fecha.toLocalDate()
                + ", firmada por " + firmadaPor.getNombreCompleto() + "): " + texto;
    }
}
