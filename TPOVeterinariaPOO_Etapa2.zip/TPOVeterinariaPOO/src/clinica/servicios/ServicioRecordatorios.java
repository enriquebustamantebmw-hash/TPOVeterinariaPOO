package clinica.servicios;

import clinica.modelo.historia.VacunaAplicada;
import clinica.modelo.mascotas.Mascota;
import clinica.persistencia.Repositorio;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class ServicioRecordatorios {
    private final Repositorio<Mascota> mascotas;
    private final Notificador notificador;
    // para no mandar dos veces el mismo recordatorio
    private final Set<String> recordatoriosEnviados;

    public ServicioRecordatorios(Repositorio<Mascota> mascotas, Notificador notificador,
                                 Set<String> recordatoriosEnviados) {
        this.mascotas = mascotas;
        this.notificador = notificador;
        this.recordatoriosEnviados = recordatoriosEnviados;
    }

    /** Vacunas cuyo refuerzo cae en los próximos 7 días, ordenadas por fecha de refuerzo. */
    public List<VacunaPorVencer> vacunasProximasAVencer(LocalDate hoy) {
        List<VacunaPorVencer> resultado = new ArrayList<>();
        for (Mascota mascota : mascotas.listar()) {
            for (VacunaAplicada v : mascota.getHistoriaClinica().vacunasProximasAVencer(hoy)) {
                resultado.add(new VacunaPorVencer(mascota, v));
            }
        }
        resultado.sort(Comparator.comparing((VacunaPorVencer v) -> v.getAplicacion().getProximoRefuerzo())
                .thenComparing(v -> v.getMascota().getNombre()));
        return resultado;
    }

    /** @return cuántos recordatorios nuevos se mandaron */
    public int emitirRecordatorios(LocalDate hoy) {
        int enviados = 0;
        for (VacunaPorVencer v : vacunasProximasAVencer(hoy)) {
            Mascota mascota = v.getMascota();
            String clave = mascota.getId() + "|" + v.getAplicacion().getVacuna().getNombre() + "|"
                    + v.getAplicacion().getProximoRefuerzo();
            if (recordatoriosEnviados.add(clave)) {
                notificador.enviar(mascota.getDueno().getEmail(), "A " + mascota.getNombre()
                        + " le toca el refuerzo de " + v.getAplicacion().getVacuna().getNombre()
                        + " el " + v.getAplicacion().getProximoRefuerzo() + ". Pida su turno en Patitas.");
                enviados++;
            }
        }
        return enviados;
    }
}
