package clinica.servicios;

/** Forma de avisarle algo a alguien. Hoy lo dejamos en un archivo; mañana podría ser mail o WhatsApp. */
public interface Notificador {
    void enviar(String destinatario, String mensaje);
}
