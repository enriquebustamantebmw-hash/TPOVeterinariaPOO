package clinica.servicios;

import clinica.modelo.stock.Insumo;

/** Lo implementan las clases que quieren enterarse cuando un producto llega al stock mínimo. */
public interface ObservadorStock {
    void stockBajo(Insumo insumo, int disponible);
}
