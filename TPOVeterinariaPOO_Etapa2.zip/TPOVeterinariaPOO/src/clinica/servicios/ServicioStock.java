package clinica.servicios;

import clinica.excepciones.NoEncontradoException;
import clinica.excepciones.StockInsuficienteException;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import clinica.persistencia.Repositorio;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class ServicioStock {
    private final Repositorio<Insumo> insumos;
    private final List<ObservadorStock> observadores = new ArrayList<>();

    public ServicioStock(Repositorio<Insumo> insumos) {
        this.insumos = insumos;
    }

    public void suscribir(ObservadorStock observador) {
        observadores.add(observador);
    }

    public Insumo buscar(String codigo) throws NoEncontradoException {
        return insumos.buscar(codigo.trim().toUpperCase())
                .orElseThrow(() -> new NoEncontradoException("el producto", codigo));
    }

    /** Controla que haya stock de todo lo pedido antes de descontar nada. */
    public void verificarDisponibilidad(Map<String, Integer> pedido, LocalDate hoy)
            throws NoEncontradoException, StockInsuficienteException {
        for (Map.Entry<String, Integer> item : pedido.entrySet()) {
            Insumo insumo = buscar(item.getKey());
            int disponible = insumo.getStockDisponible(hoy);
            if (disponible < item.getValue()) {
                throw new StockInsuficienteException(insumo.getNombre(), item.getValue(), disponible);
            }
        }
    }

    /** Descuenta del lote que vence primero y avisa si el producto quedó en el mínimo. */
    public List<String> consumir(String codigo, int cantidad, LocalDate hoy)
            throws NoEncontradoException, StockInsuficienteException {
        Insumo insumo = buscar(codigo);
        List<String> lotesUsados = insumo.descontar(cantidad, hoy);
        if (insumo.estaBajoMinimo(hoy)) {
            for (ObservadorStock observador : observadores) {
                observador.stockBajo(insumo, insumo.getStockDisponible(hoy));
            }
        }
        return lotesUsados;
    }

    public void registrarInsumo(Insumo insumo) {
        insumos.guardar(insumo);
    }

    public void ingresarLote(String codigo, Lote lote) throws NoEncontradoException {
        buscar(codigo).agregarLote(lote);
    }

    /** Productos en el mínimo o por debajo, primero los que están peor. */
    public List<Insumo> productosConStockBajo(LocalDate hoy) {
        List<Insumo> resultado = new ArrayList<>();
        for (Insumo insumo : insumos.listar()) {
            if (insumo.estaBajoMinimo(hoy)) {
                resultado.add(insumo);
            }
        }
        resultado.sort(Comparator.comparingInt((Insumo i) -> i.getStockDisponible(hoy) - i.getStockMinimo())
                .thenComparing(Insumo::getNombre));
        return resultado;
    }

    public List<Insumo> listar() {
        List<Insumo> lista = new ArrayList<>(insumos.listar());
        lista.sort(Comparator.comparing(Insumo::getCodigo));
        return lista;
    }
}
