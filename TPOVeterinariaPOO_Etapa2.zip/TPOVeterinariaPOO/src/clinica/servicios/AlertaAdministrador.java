package clinica.servicios;

import clinica.modelo.stock.Insumo;

public class AlertaAdministrador implements ObservadorStock {
    private final Notificador notificador;

    public AlertaAdministrador(Notificador notificador) {
        this.notificador = notificador;
    }

    @Override
    public void stockBajo(Insumo insumo, int disponible) {
        notificador.enviar("Administración", "Reponer " + insumo.getNombre() + " [" + insumo.getCodigo()
                + "]: quedan " + disponible + " unidades (mínimo " + insumo.getStockMinimo() + ")");
    }
}
