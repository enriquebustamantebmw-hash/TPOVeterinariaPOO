package clinica.servicios;

import clinica.modelo.historia.VacunaAplicada;
import clinica.modelo.mascotas.Mascota;

public class VacunaPorVencer {
    private final Mascota mascota;
    private final VacunaAplicada aplicacion;

    public VacunaPorVencer(Mascota mascota, VacunaAplicada aplicacion) {
        this.mascota = mascota;
        this.aplicacion = aplicacion;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public VacunaAplicada getAplicacion() {
        return aplicacion;
    }

    @Override
    public String toString() {
        return aplicacion.getProximoRefuerzo() + " - " + mascota.getNombre() + " (#" + mascota.getNumero() + ") - "
                + aplicacion.getVacuna().getNombre() + " - dueño: " + mascota.getDueno().getNombreCompleto()
                + " (" + mascota.getDueno().getTelefono() + ")";
    }
}
