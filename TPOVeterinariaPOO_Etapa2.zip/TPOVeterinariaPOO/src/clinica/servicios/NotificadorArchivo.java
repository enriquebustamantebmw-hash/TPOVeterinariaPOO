package clinica.servicios;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Como no tenemos un servidor de mail, los avisos se muestran por pantalla
 * y se guardan en datos/notificaciones.txt.
 */
public class NotificadorArchivo implements Notificador {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Path archivo;

    public NotificadorArchivo(Path archivo) {
        this.archivo = archivo;
    }

    @Override
    public void enviar(String destinatario, String mensaje) {
        System.out.println("  >> Aviso a " + destinatario + ": " + mensaje);
        String linea = LocalDateTime.now().format(FORMATO) + " | " + destinatario + " | " + mensaje;
        try {
            if (archivo.getParent() != null) {
                Files.createDirectories(archivo.getParent());
            }
            try (BufferedWriter writer = Files.newBufferedWriter(archivo, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                writer.write(linea);
                writer.newLine();
            }
        } catch (IOException e) {
            // si no se puede escribir el archivo el aviso igual se mostró por pantalla
            System.out.println("  (no se pudo guardar el aviso en " + archivo + ": " + e.getMessage() + ")");
        }
    }
}
