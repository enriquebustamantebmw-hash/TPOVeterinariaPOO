package clinica.excepciones;

public class SenaRequeridaException extends ReglaNegocioException {
    public SenaRequeridaException(String nombreDueno, int ausencias) {
        super(nombreDueno + " tiene " + ausencias + " ausencias seguidas y debe abonar una seña antes de pedir un turno");
    }
}
