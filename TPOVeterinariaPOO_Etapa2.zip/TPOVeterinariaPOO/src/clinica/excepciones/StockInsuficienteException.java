package clinica.excepciones;

public class StockInsuficienteException extends ReglaNegocioException {
    public StockInsuficienteException(String producto, int pedido, int disponible) {
        super("No hay stock suficiente de " + producto + ": se piden " + pedido + " y hay " + disponible + " sin vencer");
    }
}
