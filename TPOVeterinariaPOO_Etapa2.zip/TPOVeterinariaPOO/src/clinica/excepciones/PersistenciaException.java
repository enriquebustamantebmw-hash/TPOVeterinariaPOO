package clinica.excepciones;

public class PersistenciaException extends ClinicaException {
    public PersistenciaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
