package clinica.excepciones;

public class NoEncontradoException extends ClinicaException {
    public NoEncontradoException(String que, Object id) {
        super("No existe " + que + " " + id);
    }
}
