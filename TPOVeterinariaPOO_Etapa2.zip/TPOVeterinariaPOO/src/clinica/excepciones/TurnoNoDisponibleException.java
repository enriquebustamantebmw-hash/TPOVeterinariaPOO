package clinica.excepciones;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TurnoNoDisponibleException extends ReglaNegocioException {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final LocalDateTime primerHorarioLibre;

    public TurnoNoDisponibleException(LocalDateTime pedido, LocalDateTime primerHorarioLibre) {
        super("El horario " + pedido.format(FORMATO) + " no está disponible"
                + (primerHorarioLibre != null ? ". Primer horario libre: " + primerHorarioLibre.format(FORMATO) : ""));
        this.primerHorarioLibre = primerHorarioLibre;
    }

    public LocalDateTime getPrimerHorarioLibre() {
        return primerHorarioLibre;
    }
}
