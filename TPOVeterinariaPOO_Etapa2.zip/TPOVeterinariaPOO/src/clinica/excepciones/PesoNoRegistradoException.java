package clinica.excepciones;

public class PesoNoRegistradoException extends ReglaNegocioException {
    public PesoNoRegistradoException() {
        super("No se puede indicar un medicamento si no se registró el peso del animal en la consulta");
    }
}
