package clinica.excepciones;

/** Excepción base del sistema. Todas las propias heredan de esta. */
public class ClinicaException extends Exception {
    public ClinicaException(String mensaje) {
        super(mensaje);
    }

    public ClinicaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
