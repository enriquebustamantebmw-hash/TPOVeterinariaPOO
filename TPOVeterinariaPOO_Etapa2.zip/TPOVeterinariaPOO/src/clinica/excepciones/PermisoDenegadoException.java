package clinica.excepciones;

public class PermisoDenegadoException extends ReglaNegocioException {
    public PermisoDenegadoException(String mensaje) {
        super(mensaje);
    }
}
