package clinica.excepciones;

public class VacunaNoAplicableException extends ReglaNegocioException {
    public VacunaNoAplicableException(String mensaje) {
        super(mensaje);
    }
}
