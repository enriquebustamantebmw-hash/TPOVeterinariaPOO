package clinica.excepciones;

/** Se lanza cuando una operación no cumple alguna regla de negocio del enunciado. */
public class ReglaNegocioException extends ClinicaException {
    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
