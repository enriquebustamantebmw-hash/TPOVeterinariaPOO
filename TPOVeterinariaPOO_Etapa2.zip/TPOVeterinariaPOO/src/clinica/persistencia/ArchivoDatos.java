package clinica.persistencia;

import clinica.excepciones.PersistenciaException;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Guarda y lee toda la base de datos en un archivo para que no se pierda al cerrar el programa. */
public class ArchivoDatos {
    private final Path ruta;

    public ArchivoDatos(Path ruta) {
        this.ruta = ruta;
    }

    public boolean existe() {
        return Files.exists(ruta);
    }

    public BaseDeDatos cargar() throws PersistenciaException {
        ObjectInputStream entrada = null;
        try {
            entrada = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(ruta)));
            return (BaseDeDatos) entrada.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            throw new PersistenciaException("No se pudieron leer los datos de " + ruta, e);
        } finally {
            cerrar(entrada);
        }
    }

    public void guardar(BaseDeDatos base) throws PersistenciaException {
        ObjectOutputStream salida = null;
        try {
            if (ruta.getParent() != null) {
                Files.createDirectories(ruta.getParent());
            }
            salida = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(ruta)));
            salida.writeObject(base);
        } catch (IOException e) {
            throw new PersistenciaException("No se pudieron guardar los datos en " + ruta, e);
        } finally {
            cerrar(salida);
        }
    }

    private void cerrar(AutoCloseable recurso) {
        if (recurso != null) {
            try {
                recurso.close();
            } catch (Exception e) {
                System.out.println("Aviso: no se pudo cerrar el archivo " + ruta);
            }
        }
    }
}
