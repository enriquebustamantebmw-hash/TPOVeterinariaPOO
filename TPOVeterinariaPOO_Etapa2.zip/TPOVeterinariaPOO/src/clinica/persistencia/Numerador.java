package clinica.persistencia;

/** Da números correlativos (turnos, mascotas, facturas...). */
public interface Numerador {
    int siguiente(String tipo);
}
