package clinica.persistencia;

import clinica.excepciones.ClinicaException;
import clinica.modelo.historia.NuevaConsulta;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.mascotas.Ave;
import clinica.modelo.mascotas.Conejo;
import clinica.modelo.mascotas.Especie;
import clinica.modelo.mascotas.Gato;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.mascotas.Perro;
import clinica.modelo.mascotas.Sexo;
import clinica.modelo.mascotas.Tamanio;
import clinica.modelo.personas.Administrador;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.PlanSalud;
import clinica.modelo.personas.Recepcionista;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import clinica.modelo.stock.Medicamento;
import clinica.modelo.stock.Proveedor;
import clinica.modelo.turnos.Cirugia;
import clinica.modelo.turnos.ConsultaGeneral;
import clinica.modelo.turnos.Turno;
import clinica.modelo.turnos.Vacunacion;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.EnumSet;

/**
 * Datos de prueba que se cargan la primera vez que se ejecuta el programa
 * (cuando todavía no existe datos/clinica.dat). Las fechas se calculan a partir de hoy.
 */
public final class DatosIniciales {

    private DatosIniciales() {
    }

    public static void cargar(BaseDeDatos db, LocalDate hoy) {
        // ---- personal ----
        Veterinario gomez = new Veterinario("Laura", "Gómez", "30111222", "11-4555-1111", "MP-1234", "Clínica general");
        for (DayOfWeek dia : EnumSet.range(DayOfWeek.MONDAY, DayOfWeek.SATURDAY)) {
            gomez.definirHorario(dia, LocalTime.of(9, 0), LocalTime.of(19, 0));
        }
        gomez.setDeGuardia(true);

        Veterinario perez = new Veterinario("Martín", "Pérez", "28999888", "11-4555-2222", "MP-5678", "Cirugía");
        perez.definirHorario(DayOfWeek.MONDAY, LocalTime.of(9, 0), LocalTime.of(13, 0));
        perez.definirHorario(DayOfWeek.WEDNESDAY, LocalTime.of(9, 0), LocalTime.of(13, 0));
        perez.definirHorario(DayOfWeek.FRIDAY, LocalTime.of(9, 0), LocalTime.of(13, 0));
        perez.definirHorario(DayOfWeek.TUESDAY, LocalTime.of(14, 0), LocalTime.of(19, 0));
        perez.definirHorario(DayOfWeek.THURSDAY, LocalTime.of(14, 0), LocalTime.of(19, 0));

        db.getEmpleados().guardar(gomez);
        db.getEmpleados().guardar(perez);
        db.getEmpleados().guardar(new Recepcionista("Sofía", "Ruiz", "35123456", "11-4555-3333"));
        db.getEmpleados().guardar(new Administrador("Carlos", "Díaz", "25987654", "11-4555-4444"));

        // ---- plan de salud ----
        PlanSalud plan = new PlanSalud("Plan Salud Animal");
        db.getPlanes().guardar(plan);

        // ---- dueños ----
        Dueno ana = new Dueno("Ana", "López", "40111222", "11-6000-1111", "ana.lopez@mail.com");
        ana.adherirAPlan(plan);
        Dueno juan = new Dueno("Juan", "Martínez", "38222333", "11-6000-2222", "juan.martinez@mail.com");
        Dueno pedro = new Dueno("Pedro", "Sosa", "41333444", "11-6000-3333", "pedro.sosa@mail.com");
        for (int i = 0; i < 3; i++) {
            pedro.registrarAusencia(); // ya faltó tres veces seguidas: tiene que pagar seña
        }
        db.getDuenos().guardar(ana);
        db.getDuenos().guardar(juan);
        db.getDuenos().guardar(pedro);

        // ---- mascotas ----
        Mascota firulais = new Perro(db.siguiente("mascota"), "Firulais", "Mestizo", Sexo.MACHO, hoy.minusYears(3),
                18.5, ana, "985112003456789", Tamanio.MEDIANO);
        Mascota michi = new Gato(db.siguiente("mascota"), "Michi", "Siamés", Sexo.HEMBRA, hoy.minusYears(2),
                4.2, ana, true);
        Mascota kiwi = new Ave(db.siguiente("mascota"), "Kiwi", "Cotorra", Sexo.MACHO, hoy.minusYears(1),
                0.1, juan, true);
        Mascota copo = new Conejo(db.siguiente("mascota"), "Copo", "Angora", Sexo.HEMBRA, hoy.minusYears(1),
                2.1, juan, "largo");
        Mascota toby = new Perro(db.siguiente("mascota"), "Toby", "Caniche", Sexo.MACHO, hoy.minusWeeks(5),
                1.2, pedro, "", Tamanio.CHICO);
        for (Mascota m : new Mascota[]{firulais, michi, kiwi, copo, toby}) {
            db.getMascotas().guardar(m);
        }

        // ---- proveedores y stock ----
        Proveedor vetsur = new Proveedor("Distribuidora VetSur", "11-4777-0000");
        Proveedor holliday = new Proveedor("Laboratorio Holliday", "11-4888-0000");
        db.getProveedores().guardar(vetsur);
        db.getProveedores().guardar(holliday);

        Insumo antirrabica = new Insumo("V-ANT", "Vacuna antirrábica (dosis)", 5, 8000);
        antirrabica.agregarLote(new Lote("L-ANT-01", hoy.minusDays(10), 4, holliday)); // vencido, no se usa
        antirrabica.agregarLote(new Lote("L-ANT-02", hoy.plusDays(60), 6, holliday));
        antirrabica.agregarLote(new Lote("L-ANT-03", hoy.plusDays(200), 10, holliday));
        Insumo sextuple = new Insumo("V-SEX", "Vacuna séxtuple canina (dosis)", 4, 9500);
        sextuple.agregarLote(new Lote("L-SEX-01", hoy.plusDays(120), 8, holliday));
        Insumo triple = new Insumo("V-TRI", "Vacuna triple felina (dosis)", 4, 9000);
        triple.agregarLote(new Lote("L-TRI-01", hoy.plusDays(90), 5, holliday));
        Insumo mixomatosis = new Insumo("V-MIX", "Vacuna mixomatosis (dosis)", 2, 7000);
        mixomatosis.agregarLote(new Lote("L-MIX-01", hoy.plusDays(150), 3, holliday));
        Insumo jeringa = new Insumo("JER", "Jeringa descartable 5 ml", 10, 300);
        jeringa.agregarLote(new Lote("L-JER-01", hoy.plusDays(400), 11, vetsur));
        Insumo gasas = new Insumo("GAS", "Gasas estériles (paquete)", 5, 900);
        gasas.agregarLote(new Lote("L-GAS-01", hoy.plusDays(300), 20, vetsur));
        Medicamento amoxicilina = new Medicamento("AMOX", "Amoxicilina 500 mg", 5, 4500, "Amoxicilina", "Comprimidos");
        amoxicilina.agregarLote(new Lote("L-AMOX-01", hoy.plusDays(180), 12, vetsur));
        Medicamento meloxicam = new Medicamento("MELOX", "Meloxicam 1,5 mg/ml", 3, 6000, "Meloxicam", "Gotas");
        meloxicam.agregarLote(new Lote("L-MEL-01", hoy.plusDays(240), 3, vetsur));
        for (Insumo i : new Insumo[]{antirrabica, sextuple, triple, mixomatosis, jeringa, gasas, amoxicilina, meloxicam}) {
            db.getInsumos().guardar(i);
        }

        // ---- catálogo de vacunas ----
        Vacuna vAntirrabica = new Vacuna("Antirrábica", EnumSet.of(Especie.PERRO, Especie.GATO), 3, 365, "V-ANT");
        Vacuna vSextuple = new Vacuna("Séxtuple", EnumSet.of(Especie.PERRO), 2, 365, "V-SEX");
        Vacuna vTriple = new Vacuna("Triple felina", EnumSet.of(Especie.GATO), 2, 365, "V-TRI");
        Vacuna vMixo = new Vacuna("Mixomatosis", EnumSet.of(Especie.CONEJO), 2, 180, "V-MIX");
        for (Vacuna v : new Vacuna[]{vAntirrabica, vSextuple, vTriple, vMixo}) {
            db.getVacunas().guardar(v);
        }

        // ---- historia clínica previa (para que haya vacunas por vencer) ----
        NuevaConsulta c1 = new NuevaConsulta(gomez, hoy.minusDays(360).atTime(10, 0), "Control anual", 18.0,
                "Sano", "", null);
        c1.agregarVacuna(vAntirrabica, "L-ANT-00");
        firulais.getHistoriaClinica().registrarConsulta(c1);

        NuevaConsulta c2 = new NuevaConsulta(gomez, hoy.minusDays(340).atTime(11, 0), "Vacunación", 4.0,
                "Sano", "", null);
        c2.agregarVacuna(vTriple, "L-TRI-00");
        michi.getHistoriaClinica().registrarConsulta(c2);

        NuevaConsulta c3 = new NuevaConsulta(gomez, hoy.minusDays(176).atTime(12, 0), "Vacunación", 2.0,
                "Sano", "", null);
        c3.agregarVacuna(vMixo, "L-MIX-00");
        copo.getHistoriaClinica().registrarConsulta(c3);

        // ---- turnos ----
        try {
            LocalDate dia = proximoDia(hoy, EnumSet.range(DayOfWeek.MONDAY, DayOfWeek.SATURDAY));
            agregarTurno(db, gomez.getAgenda().crearTurno(db.siguiente("turno"), firulais, dia.atTime(10, 0),
                    new ConsultaGeneral()));
            agregarTurno(db, gomez.getAgenda().crearTurno(db.siguiente("turno"), michi, dia.atTime(10, 30),
                    new Vacunacion()));
            agregarTurno(db, gomez.getAgenda().crearTurno(db.siguiente("turno"), kiwi, dia.atTime(11, 0),
                    new ConsultaGeneral()));
            LocalDate diaCirugia = proximoDia(hoy, EnumSet.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY));
            agregarTurno(db, perez.getAgenda().crearTurno(db.siguiente("turno"), copo, diaCirugia.atTime(9, 0),
                    new Cirugia()));
        } catch (ClinicaException e) {
            // no debería pasar porque los horarios están armados a mano
            System.out.println("No se pudieron cargar los turnos de prueba: " + e.getMessage());
        }
    }

    private static void agregarTurno(BaseDeDatos db, Turno turno) {
        db.getTurnos().guardar(turno);
    }

    private static LocalDate proximoDia(LocalDate hoy, EnumSet<DayOfWeek> dias) {
        LocalDate dia = hoy.plusDays(1);
        while (!dias.contains(dia.getDayOfWeek())) {
            dia = dia.plusDays(1);
        }
        return dia;
    }
}
