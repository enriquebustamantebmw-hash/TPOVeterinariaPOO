package clinica.persistencia;

import clinica.modelo.Identificable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class RepositorioEnMemoria<T extends Identificable> implements Repositorio<T>, Serializable {
    private final Map<String, T> elementos = new LinkedHashMap<>();

    @Override
    public void guardar(T elemento) {
        elementos.put(elemento.getId(), elemento);
    }

    @Override
    public Optional<T> buscar(String id) {
        return Optional.ofNullable(elementos.get(id));
    }

    @Override
    public List<T> listar() {
        return new ArrayList<>(elementos.values());
    }

    @Override
    public boolean existe(String id) {
        return elementos.containsKey(id);
    }
}
