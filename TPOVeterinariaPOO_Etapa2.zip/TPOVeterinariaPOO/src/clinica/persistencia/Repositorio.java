package clinica.persistencia;

import clinica.modelo.Identificable;

import java.util.List;
import java.util.Optional;

/** Los controladores dependen de esta interfaz y no de cómo se guardan los datos. */
public interface Repositorio<T extends Identificable> {
    void guardar(T elemento);

    Optional<T> buscar(String id);

    List<T> listar();

    boolean existe(String id);
}
