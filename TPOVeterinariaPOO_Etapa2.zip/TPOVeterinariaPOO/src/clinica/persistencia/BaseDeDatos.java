package clinica.persistencia;

import clinica.modelo.facturacion.Factura;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.Empleado;
import clinica.modelo.personas.PlanSalud;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Proveedor;
import clinica.modelo.turnos.Turno;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Junta todos los repositorios para poder guardarlos en un solo archivo. */
public class BaseDeDatos implements Numerador, Serializable {
    private static final long serialVersionUID = 1L;

    private final Repositorio<Dueno> duenos = new RepositorioEnMemoria<>();
    private final Repositorio<Mascota> mascotas = new RepositorioEnMemoria<>();
    private final Repositorio<Empleado> empleados = new RepositorioEnMemoria<>();
    private final Repositorio<Turno> turnos = new RepositorioEnMemoria<>();
    private final Repositorio<Insumo> insumos = new RepositorioEnMemoria<>();
    private final Repositorio<Proveedor> proveedores = new RepositorioEnMemoria<>();
    private final Repositorio<Vacuna> vacunas = new RepositorioEnMemoria<>();
    private final Repositorio<PlanSalud> planes = new RepositorioEnMemoria<>();
    private final Repositorio<Factura> facturas = new RepositorioEnMemoria<>();
    private final Map<String, Integer> contadores = new HashMap<>();
    private final Set<String> recordatoriosEnviados = new HashSet<>();

    @Override
    public int siguiente(String tipo) {
        int numero = contadores.getOrDefault(tipo, 0) + 1;
        contadores.put(tipo, numero);
        return numero;
    }

    public Repositorio<Dueno> getDuenos() {
        return duenos;
    }

    public Repositorio<Mascota> getMascotas() {
        return mascotas;
    }

    public Repositorio<Empleado> getEmpleados() {
        return empleados;
    }

    public Repositorio<Turno> getTurnos() {
        return turnos;
    }

    public Repositorio<Insumo> getInsumos() {
        return insumos;
    }

    public Repositorio<Proveedor> getProveedores() {
        return proveedores;
    }

    public Repositorio<Vacuna> getVacunas() {
        return vacunas;
    }

    public Repositorio<PlanSalud> getPlanes() {
        return planes;
    }

    public Repositorio<Factura> getFacturas() {
        return facturas;
    }

    public Set<String> getRecordatoriosEnviados() {
        return recordatoriosEnviados;
    }
}
