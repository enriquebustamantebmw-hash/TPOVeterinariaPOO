package clinica.vista;

import clinica.controladores.ControladorAdministracion;
import clinica.controladores.ControladorConsultas;
import clinica.controladores.ControladorFacturacion;
import clinica.controladores.ControladorMascotas;
import clinica.controladores.ControladorTurnos;
import clinica.controladores.DatosConsulta;
import clinica.excepciones.ClinicaException;
import clinica.excepciones.PersistenciaException;
import clinica.excepciones.TurnoNoDisponibleException;
import clinica.modelo.facturacion.Credito;
import clinica.modelo.facturacion.Debito;
import clinica.modelo.facturacion.Efectivo;
import clinica.modelo.facturacion.Factura;
import clinica.modelo.facturacion.MedioPago;
import clinica.modelo.facturacion.NotaCredito;
import clinica.modelo.historia.Consulta;
import clinica.modelo.historia.HistoriaClinica;
import clinica.modelo.historia.NotaRectificatoria;
import clinica.modelo.historia.Vacuna;
import clinica.modelo.historia.VacunaAplicada;
import clinica.modelo.mascotas.Mascota;
import clinica.modelo.mascotas.Sexo;
import clinica.modelo.mascotas.Tamanio;
import clinica.modelo.personas.Dueno;
import clinica.modelo.personas.Empleado;
import clinica.modelo.personas.HorarioAtencion;
import clinica.modelo.personas.PlanSalud;
import clinica.modelo.personas.Veterinario;
import clinica.modelo.stock.Insumo;
import clinica.modelo.stock.Lote;
import clinica.modelo.stock.Medicamento;
import clinica.modelo.turnos.TipoAtencion;
import clinica.modelo.turnos.Turno;
import clinica.persistencia.ArchivoDatos;
import clinica.persistencia.BaseDeDatos;
import clinica.servicios.VacunaPorVencer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/** Interfaz por consola. Solo pide datos y muestra resultados: la lógica está en los controladores. */
public class MenuConsola {
    private final Consola consola;
    private final ArchivoDatos archivo;
    private final BaseDeDatos base;
    private final ControladorMascotas mascotas;
    private final ControladorTurnos turnos;
    private final ControladorConsultas consultas;
    private final ControladorFacturacion facturacion;
    private final ControladorAdministracion administracion;

    public MenuConsola(Consola consola, ArchivoDatos archivo, BaseDeDatos base, ControladorMascotas mascotas,
                       ControladorTurnos turnos, ControladorConsultas consultas, ControladorFacturacion facturacion,
                       ControladorAdministracion administracion) {
        this.consola = consola;
        this.archivo = archivo;
        this.base = base;
        this.mascotas = mascotas;
        this.turnos = turnos;
        this.consultas = consultas;
        this.facturacion = facturacion;
        this.administracion = administracion;
    }

    public void iniciar() {
        try {
            boolean seguir = true;
            while (seguir) {
                System.out.println();
                System.out.println("===== CLÍNICA VETERINARIA PATITAS =====");
                System.out.println("1. Dueños y mascotas");
                System.out.println("2. Turnos");
                System.out.println("3. Consultas e historia clínica");
                System.out.println("4. Facturación");
                System.out.println("5. Stock");
                System.out.println("6. Administración y reportes");
                System.out.println("7. Guardar datos");
                System.out.println("0. Salir");
                int opcion = consola.leerOpcion("Opción: ", 0, 7);
                switch (opcion) {
                    case 1: menuMascotas(); break;
                    case 2: menuTurnos(); break;
                    case 3: menuConsultas(); break;
                    case 4: menuFacturacion(); break;
                    case 5: menuStock(); break;
                    case 6: menuAdministracion(); break;
                    case 7: guardar(); break;
                    default: seguir = false;
                }
            }
        } catch (FinDeEntradaException e) {
            System.out.println();
            System.out.println("Fin de la entrada.");
        } finally {
            // pase lo que pase, al salir se guardan los datos
            guardar();
            System.out.println("Hasta luego.");
        }
    }

    private void guardar() {
        try {
            archivo.guardar(base);
            System.out.println("Datos guardados.");
        } catch (PersistenciaException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    /** Ejecuta una acción y si tira una excepción del sistema muestra el mensaje. */
    private void ejecutar(Accion accion) {
        try {
            accion.ejecutar();
        } catch (ClinicaException e) {
            System.out.println("ERROR: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Dato inválido: " + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface Accion {
        void ejecutar() throws ClinicaException;
    }

    // =================== 1. Dueños y mascotas ===================

    private void menuMascotas() {
        System.out.println();
        System.out.println("--- Dueños y mascotas ---");
        System.out.println("1. Registrar dueño");
        System.out.println("2. Registrar mascota");
        System.out.println("3. Transferir mascota a otro dueño");
        System.out.println("4. Adherir / quitar plan de salud");
        System.out.println("5. Listar dueños");
        System.out.println("6. Listar mascotas");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 6)) {
            case 1: ejecutar(this::registrarDueno); break;
            case 2: ejecutar(this::registrarMascota); break;
            case 3: ejecutar(this::transferirMascota); break;
            case 4: ejecutar(this::planDeSalud); break;
            case 5: listarDuenos(); break;
            case 6: listarMascotas(); break;
            default: break;
        }
    }

    private void registrarDueno() throws ClinicaException {
        String nombre = consola.leerTexto("Nombre: ");
        String apellido = consola.leerTexto("Apellido: ");
        String dni = consola.leerTexto("DNI: ");
        String telefono = consola.leerTexto("Teléfono: ");
        String email = consola.leerTexto("Email: ");
        Dueno dueno = mascotas.registrarDueno(nombre, apellido, dni, telefono, email);
        System.out.println("Dueño registrado: " + dueno);
    }

    private void registrarMascota() throws ClinicaException {
        String dni = consola.leerTexto("DNI del dueño: ");
        mascotas.buscarDueno(dni); // para avisar antes de pedir todo lo demás
        System.out.println("Especie: 1. Perro  2. Gato  3. Ave  4. Conejo");
        int especie = consola.leerOpcion("Opción: ", 1, 4);
        String nombre = consola.leerTexto("Nombre: ");
        String raza = consola.leerTexto("Raza: ");
        Sexo sexo = consola.leerOpcion("Sexo (1. Macho  2. Hembra): ", 1, 2) == 1 ? Sexo.MACHO : Sexo.HEMBRA;
        LocalDate nacimiento = consola.leerFecha("Fecha de nacimiento");
        double peso = consola.leerDecimal("Peso actual (kg): ");
        Mascota mascota;
        switch (especie) {
            case 1:
                String chip = consola.leerTextoOpcional("Número de chip (Enter si no tiene): ");
                int tam = consola.leerOpcion("Tamaño (1. Chico  2. Mediano  3. Grande): ", 1, 3);
                mascota = mascotas.registrarPerro(dni, nombre, raza, sexo, nacimiento, peso, chip, Tamanio.values()[tam - 1]);
                break;
            case 2:
                boolean interior = consola.leerSiNo("¿Vive en interior?");
                mascota = mascotas.registrarGato(dni, nombre, raza, sexo, nacimiento, peso, interior);
                break;
            case 3:
                boolean vuela = consola.leerSiNo("¿Puede volar?");
                mascota = mascotas.registrarAve(dni, nombre, raza, sexo, nacimiento, peso, vuela);
                break;
            default:
                String pelaje = consola.leerTexto("Tipo de pelaje: ");
                mascota = mascotas.registrarConejo(dni, nombre, raza, sexo, nacimiento, peso, pelaje);
        }
        System.out.println("Mascota registrada: " + mascota);
    }

    private void transferirMascota() throws ClinicaException {
        int numero = consola.leerEntero("Número de mascota: ");
        String dni = consola.leerTexto("DNI del nuevo dueño: ");
        mascotas.transferirMascota(numero, dni);
        Mascota mascota = mascotas.buscarMascota(numero);
        int consultasPrevias = mascota.getHistoriaClinica().getConsultas().size();
        System.out.println("Listo: " + mascota);
        System.out.println("La historia clínica se conserva (" + consultasPrevias
                + (consultasPrevias == 1 ? " consulta)." : " consultas)."));
    }

    private void planDeSalud() throws ClinicaException {
        String dni = consola.leerTexto("DNI del dueño: ");
        Dueno dueno = mascotas.buscarDueno(dni);
        System.out.println("Plan actual: " + (dueno.tienePlan() ? dueno.getPlan() : "ninguno"));
        if (dueno.tienePlan() && consola.leerSiNo("¿Quitar el plan?")) {
            mascotas.quitarPlan(dni);
            System.out.println("Plan quitado.");
            return;
        }
        List<PlanSalud> planes = mascotas.listarPlanes();
        for (int i = 0; i < planes.size(); i++) {
            System.out.println((i + 1) + ". " + planes.get(i));
        }
        int opcion = consola.leerOpcion("Plan (0 para volver): ", 0, planes.size());
        if (opcion > 0) {
            mascotas.adherirAPlan(dni, planes.get(opcion - 1).getNombre());
            System.out.println(dueno.getNombreCompleto() + " quedó adherido a " + planes.get(opcion - 1).getNombre());
        }
    }

    private void listarDuenos() {
        for (Dueno d : mascotas.listarDuenos()) {
            System.out.println(d + " - " + d.getEmail() + " - plan: " + (d.tienePlan() ? d.getPlan().getNombre() : "no")
                    + " - ausencias seguidas: " + d.getAusenciasSeguidas()
                    + (d.requiereSena() ? " (DEBE SEÑA)" : ""));
            for (Mascota m : d.getMascotas()) {
                System.out.println("     " + m.getNombre() + " (#" + m.getNumero() + ", " + m.getEspecie() + ")");
            }
        }
    }

    private void listarMascotas() {
        for (Mascota m : mascotas.listarMascotas()) {
            System.out.println(m);
        }
    }

    // =================== 2. Turnos ===================

    private void menuTurnos() {
        System.out.println();
        System.out.println("--- Turnos ---");
        System.out.println("1. Asignar turno");
        System.out.println("2. Reprogramar turno");
        System.out.println("3. Cancelar turno");
        System.out.println("4. Registrar urgencia");
        System.out.println("5. Registrar ausencia");
        System.out.println("6. Registrar pago de seña");
        System.out.println("7. Ver turnos de un veterinario");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 7)) {
            case 1: ejecutar(this::asignarTurno); break;
            case 2: ejecutar(this::reprogramarTurno); break;
            case 3: ejecutar(this::cancelarTurno); break;
            case 4: ejecutar(this::registrarUrgencia); break;
            case 5: ejecutar(this::registrarAusencia); break;
            case 6: ejecutar(this::registrarSena); break;
            case 7: ejecutar(this::verTurnosVeterinario); break;
            default: break;
        }
    }

    private String elegirVeterinario() {
        List<Veterinario> veterinarios = turnos.listarVeterinarios();
        for (int i = 0; i < veterinarios.size(); i++) {
            System.out.println((i + 1) + ". " + veterinarios.get(i));
        }
        int opcion = consola.leerOpcion("Veterinario: ", 1, veterinarios.size());
        return veterinarios.get(opcion - 1).getDocumento();
    }

    private TipoAtencion elegirTipo() {
        System.out.println("Tipo: 1. Consulta general (30 min)  2. Vacunación (15 min)  3. Cirugía (120 min)");
        return TipoAtencion.desdeOpcion(consola.leerOpcion("Opción: ", 1, 3));
    }

    private void asignarTurno() throws ClinicaException {
        int mascota = consola.leerEntero("Número de mascota: ");
        String dniVet = elegirVeterinario();
        TipoAtencion tipo = elegirTipo();
        LocalDateTime inicio = consola.leerFechaHora("Fecha y hora");
        try {
            Turno turno = turnos.asignarTurno(mascota, dniVet, inicio, tipo);
            System.out.println("Turno asignado: " + turno);
            if (turno.getSena() > 0) {
                System.out.printf("Se tomó la seña de $%,.2f para este turno.%n", turno.getSena());
            }
        } catch (TurnoNoDisponibleException e) {
            System.out.println("ERROR: " + e.getMessage());
            if (e.getPrimerHorarioLibre() != null && consola.leerSiNo("¿Lo asigno en el primer horario libre?")) {
                Turno turno = turnos.asignarTurno(mascota, dniVet, e.getPrimerHorarioLibre(), tipo);
                System.out.println("Turno asignado: " + turno);
            }
        }
    }

    private void reprogramarTurno() throws ClinicaException {
        int numero = consola.leerEntero("Número de turno: ");
        System.out.println(turnos.buscarTurno(numero));
        LocalDateTime nuevo = consola.leerFechaHora("Nueva fecha y hora");
        turnos.reprogramarTurno(numero, nuevo);
        System.out.println("Turno reprogramado: " + turnos.buscarTurno(numero));
    }

    private void cancelarTurno() throws ClinicaException {
        int numero = consola.leerEntero("Número de turno: ");
        System.out.println(turnos.buscarTurno(numero));
        LocalDateTime ahora = consola.leerFechaHoraOpcional("Momento de la cancelación");
        double cargo = turnos.cancelarTurno(numero, ahora);
        if (cargo > 0) {
            System.out.printf("Turno cancelado con cargo de $%,.2f (se suma a la próxima factura).%n", cargo);
        } else {
            System.out.println("Turno cancelado sin cargo.");
        }
    }

    private void registrarUrgencia() throws ClinicaException {
        int mascota = consola.leerEntero("Número de mascota: ");
        LocalDateTime ahora = consola.leerFechaHoraOpcional("Momento de la urgencia");
        Turno urgencia = turnos.registrarUrgencia(mascota, ahora);
        System.out.println("Urgencia registrada: " + urgencia);
    }

    private void registrarAusencia() throws ClinicaException {
        int numero = consola.leerEntero("Número de turno: ");
        LocalDateTime ahora = consola.leerFechaHoraOpcional("Momento del registro");
        turnos.registrarAusencia(numero, ahora);
        Dueno dueno = turnos.buscarTurno(numero).getMascota().getDueno();
        int ausencias = dueno.getAusenciasSeguidas();
        System.out.println("Ausencia registrada. " + dueno.getNombreCompleto() + " lleva " + ausencias
                + (ausencias == 1 ? " ausencia seguida." : " ausencias seguidas."));
    }

    private void registrarSena() throws ClinicaException {
        String dni = consola.leerTexto("DNI del dueño: ");
        double monto = consola.leerDecimal("Monto de la seña: ");
        turnos.registrarPagoSena(dni, monto);
        System.out.println("Seña registrada. Ya puede pedir un turno.");
    }

    private void verTurnosVeterinario() throws ClinicaException {
        String dni = elegirVeterinario();
        List<Turno> lista = turnos.turnosDeVeterinario(dni);
        if (lista.isEmpty()) {
            System.out.println("No tiene turnos.");
        }
        for (Turno t : lista) {
            System.out.println(t);
        }
    }

    // =================== 3. Consultas ===================

    private void menuConsultas() {
        System.out.println();
        System.out.println("--- Consultas e historia clínica ---");
        System.out.println("1. Registrar consulta");
        System.out.println("2. Ver historia clínica");
        System.out.println("3. Agregar nota rectificatoria");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 3)) {
            case 1: ejecutar(this::registrarConsulta); break;
            case 2: ejecutar(this::verHistoria); break;
            case 3: ejecutar(this::notaRectificatoria); break;
            default: break;
        }
    }

    private void registrarConsulta() throws ClinicaException {
        String dniProfesional = consola.leerTexto("DNI del profesional que registra: ");
        int mascota = consola.leerEntero("Número de mascota: ");
        int turno = consola.leerEntero("Número de turno (0 si no tiene): ");
        String motivo = consola.leerTexto("Motivo: ");
        double peso = consola.leerDecimal("Peso del día en kg (0 si no se pesó): ");
        String diagnostico = consola.leerTexto("Diagnóstico: ");
        String observaciones = consola.leerTextoOpcional("Observaciones: ");
        DatosConsulta datos = new DatosConsulta(dniProfesional, mascota, turno, motivo, peso, diagnostico, observaciones);

        while (consola.leerSiNo("¿Agregar un tratamiento?")) {
            String codigo = consola.leerTexto("  Código del medicamento: ");
            String dosis = consola.leerTexto("  Dosis: ");
            String frecuencia = consola.leerTexto("  Frecuencia: ");
            int dias = consola.leerEntero("  Duración (días): ");
            datos.agregarTratamiento(codigo, dosis, frecuencia, dias);
        }
        while (consola.leerSiNo("¿Se aplicó una vacuna?")) {
            List<Vacuna> catalogo = consultas.listarVacunas();
            for (int i = 0; i < catalogo.size(); i++) {
                System.out.println("  " + (i + 1) + ". " + catalogo.get(i));
            }
            int opcion = consola.leerOpcion("  Vacuna: ", 1, catalogo.size());
            datos.agregarVacuna(catalogo.get(opcion - 1).getNombre());
        }
        while (consola.leerSiNo("¿Se usó algún insumo?")) {
            String codigo = consola.leerTexto("  Código del insumo: ");
            int cantidad = consola.leerEntero("  Cantidad: ");
            datos.agregarInsumo(codigo, cantidad);
        }
        Consulta consulta = consultas.registrarConsulta(datos, LocalDateTime.now());
        System.out.println("Consulta registrada en la historia clínica:");
        System.out.println(consulta);
    }

    private void verHistoria() throws ClinicaException {
        int numero = consola.leerEntero("Número de mascota: ");
        Mascota mascota = mascotas.buscarMascota(numero);
        HistoriaClinica historia = consultas.consultarHistoria(numero);
        System.out.println("Historia clínica de " + mascota);
        if (historia.getConsultas().isEmpty()) {
            System.out.println("Sin consultas registradas.");
        }
        for (Consulta c : historia.getConsultas()) {
            System.out.print(c);
        }
        for (NotaRectificatoria n : historia.getNotas()) {
            System.out.println(n);
        }
        LocalDate hoy = LocalDate.now();
        for (VacunaAplicada v : historia.getUltimasAplicaciones()) {
            String estado = v.estaVencida(hoy) ? "VENCIDA" : v.estaProximaAVencer(hoy) ? "PRÓXIMA A VENCER" : "al día";
            System.out.println("Vacuna " + v.getVacuna().getNombre() + ": refuerzo el " + v.getProximoRefuerzo()
                    + " (" + estado + ")");
        }
    }

    private void notaRectificatoria() throws ClinicaException {
        String dni = consola.leerTexto("DNI del veterinario que firma: ");
        int mascota = consola.leerEntero("Número de mascota: ");
        int consulta = consola.leerEntero("Número de consulta a corregir: ");
        String texto = consola.leerTexto("Texto de la nota: ");
        NotaRectificatoria nota = consultas.agregarNotaRectificatoria(dni, mascota, consulta, texto, LocalDateTime.now());
        System.out.println("Se agregó: " + nota);
    }

    // =================== 4. Facturación ===================

    private void menuFacturacion() {
        System.out.println();
        System.out.println("--- Facturación ---");
        System.out.println("1. Facturar una consulta");
        System.out.println("2. Anular factura con nota de crédito");
        System.out.println("3. Listar facturas");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 3)) {
            case 1: ejecutar(this::facturar); break;
            case 2: ejecutar(this::anularFactura); break;
            case 3: listarFacturas(); break;
            default: break;
        }
    }

    private MedioPago elegirMedioPago() {
        System.out.println("Medio de pago: 1. Efectivo (10% desc.)  2. Débito  3. Crédito en cuotas (8% recargo)");
        int opcion = consola.leerOpcion("Opción: ", 1, 3);
        if (opcion == 1) {
            return new Efectivo();
        }
        if (opcion == 2) {
            return new Debito();
        }
        return new Credito(consola.leerOpcion("Cantidad de cuotas (1 a 12): ", 1, Credito.MAXIMO_CUOTAS));
    }

    private void facturar() throws ClinicaException {
        int mascota = consola.leerEntero("Número de mascota: ");
        HistoriaClinica historia = consultas.consultarHistoria(mascota);
        for (Consulta c : historia.getConsultas()) {
            System.out.println("  " + c.getNumero() + ". " + c.getFecha().toLocalDate() + " - " + c.getMotivo());
        }
        int consulta = consola.leerEntero("Número de consulta: ");
        MedioPago medio = elegirMedioPago();
        Factura factura = facturacion.facturarConsulta(mascota, consulta, medio, LocalDate.now());
        System.out.println(factura);
    }

    private void anularFactura() throws ClinicaException {
        int numero = consola.leerEntero("Número de factura: ");
        String motivo = consola.leerTexto("Motivo: ");
        NotaCredito nota = facturacion.anularFactura(numero, motivo, LocalDate.now());
        System.out.println(nota);
    }

    private void listarFacturas() {
        List<Factura> lista = facturacion.listarFacturas();
        if (lista.isEmpty()) {
            System.out.println("No hay facturas.");
        }
        for (Factura f : lista) {
            System.out.println(f);
        }
    }

    // =================== 5. Stock ===================

    private void menuStock() {
        System.out.println();
        System.out.println("--- Stock ---");
        System.out.println("1. Ver productos y lotes");
        System.out.println("2. Ingresar un lote");
        System.out.println("3. Dar de alta un producto");
        System.out.println("4. Productos con stock bajo");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 4)) {
            case 1: verStock(); break;
            case 2: ejecutar(this::ingresarLote); break;
            case 3: ejecutar(this::altaProducto); break;
            case 4: stockBajo(); break;
            default: break;
        }
    }

    private void verStock() {
        LocalDate hoy = LocalDate.now();
        for (Insumo i : administracion.listarProductos()) {
            System.out.println(i + " - disponible (sin vencidos): " + i.getStockDisponible(hoy));
            for (Lote lote : i.getLotes()) {
                System.out.println("     " + lote + (lote.estaVencido(hoy) ? " [VENCIDO]" : ""));
            }
        }
    }

    private void ingresarLote() throws ClinicaException {
        String codigo = consola.leerTexto("Código del producto: ");
        String lote = consola.leerTexto("Número de lote: ");
        LocalDate vencimiento = consola.leerFecha("Vencimiento");
        int cantidad = consola.leerEntero("Cantidad: ");
        String proveedor = consola.leerTexto("Proveedor: ");
        administracion.ingresarLote(codigo, lote, vencimiento, cantidad, proveedor);
        System.out.println("Lote ingresado.");
    }

    private void altaProducto() {
        boolean esMedicamento = consola.leerSiNo("¿Es un medicamento?");
        String codigo = consola.leerTexto("Código: ");
        String nombre = consola.leerTexto("Nombre: ");
        int minimo = consola.leerEntero("Stock mínimo: ");
        double precio = consola.leerDecimal("Precio: ");
        Insumo producto;
        if (esMedicamento) {
            String droga = consola.leerTexto("Droga: ");
            String presentacion = consola.leerTexto("Presentación: ");
            producto = new Medicamento(codigo, nombre, minimo, precio, droga, presentacion);
        } else {
            producto = new Insumo(codigo, nombre, minimo, precio);
        }
        administracion.registrarProducto(producto);
        System.out.println("Producto registrado: " + producto);
    }

    private void stockBajo() {
        LocalDate hoy = LocalDate.now();
        List<Insumo> lista = administracion.productosConStockBajo(hoy);
        if (lista.isEmpty()) {
            System.out.println("No hay productos con stock bajo.");
        }
        for (Insumo i : lista) {
            System.out.println(i.getCodigo() + " - " + i.getNombre() + ": " + i.getStockDisponible(hoy)
                    + " disponibles (mínimo " + i.getStockMinimo() + ")");
        }
    }

    // =================== 6. Administración ===================

    private void menuAdministracion() {
        System.out.println();
        System.out.println("--- Administración y reportes ---");
        System.out.println("1. Turnos de cada veterinario");
        System.out.println("2. Productos con stock bajo");
        System.out.println("3. Vacunas próximas a vencer");
        System.out.println("4. Emitir recordatorios de vacunas");
        System.out.println("5. Cambiar veterinario de guardia");
        System.out.println("6. Horarios de un veterinario");
        System.out.println("7. Exportar reporte a archivo");
        System.out.println("8. Ver personal");
        System.out.println("0. Volver");
        switch (consola.leerOpcion("Opción: ", 0, 8)) {
            case 1: turnosPorVeterinario(); break;
            case 2: stockBajo(); break;
            case 3: vacunasPorVencer(); break;
            case 4: emitirRecordatorios(); break;
            case 5: ejecutar(this::cambiarGuardia); break;
            case 6: ejecutar(this::horarios); break;
            case 7: ejecutar(this::exportarReporte); break;
            case 8: verPersonal(); break;
            default: break;
        }
    }

    private void turnosPorVeterinario() {
        for (Veterinario v : administracion.listarVeterinarios()) {
            System.out.println(v.getNombreCompleto() + ":");
            List<Turno> lista = administracion.turnosDe(v);
            if (lista.isEmpty()) {
                System.out.println("   sin turnos");
            }
            for (Turno t : lista) {
                System.out.println("   " + t);
            }
        }
    }

    private void vacunasPorVencer() {
        List<VacunaPorVencer> lista = administracion.vacunasProximasAVencer(LocalDate.now());
        if (lista.isEmpty()) {
            System.out.println("No hay vacunas próximas a vencer.");
        }
        for (VacunaPorVencer v : lista) {
            System.out.println(v);
        }
    }

    private void emitirRecordatorios() {
        int enviados = administracion.emitirRecordatorios(LocalDate.now());
        System.out.println("Recordatorios enviados: " + enviados);
    }

    private void cambiarGuardia() throws ClinicaException {
        String dni = elegirVeterinario();
        administracion.definirGuardia(dni);
        System.out.println("Guardia actualizada.");
    }

    private void horarios() throws ClinicaException {
        String dni = elegirVeterinario();
        Veterinario vet = null;
        for (Veterinario v : administracion.listarVeterinarios()) {
            if (v.getDocumento().equals(dni)) {
                vet = v;
            }
        }
        for (HorarioAtencion h : vet.getHorarios()) {
            System.out.println("   " + h);
        }
        if (consola.leerSiNo("¿Modificar un día?")) {
            System.out.println("Día: 1. Lunes ... 7. Domingo");
            DayOfWeek dia = DayOfWeek.of(consola.leerOpcion("Opción: ", 1, 7));
            if (consola.leerSiNo("¿Ese día no atiende?")) {
                administracion.quitarHorario(dni, dia);
            } else {
                LocalTime desde = consola.leerHora("Desde");
                LocalTime hasta = consola.leerHora("Hasta");
                administracion.definirHorario(dni, dia, desde, hasta);
            }
            System.out.println("Horario actualizado.");
        }
    }

    private void exportarReporte() throws ClinicaException {
        Path ruta = Paths.get("datos", "reporte.txt");
        administracion.exportarReporte(ruta, LocalDate.now());
        System.out.println("Reporte guardado en " + ruta.toAbsolutePath());
    }

    private void verPersonal() {
        for (Empleado e : administracion.listarEmpleados()) {
            System.out.println(e);
        }
    }
}
