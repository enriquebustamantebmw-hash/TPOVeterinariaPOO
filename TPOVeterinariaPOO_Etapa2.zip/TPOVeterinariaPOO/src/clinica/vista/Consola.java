package clinica.vista;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/** Métodos para leer datos del teclado volviendo a preguntar si el dato es inválido. */
public class Consola {
    public static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Scanner scanner;

    public Consola(Scanner scanner) {
        this.scanner = scanner;
    }

    private String leerLinea(String mensaje) {
        System.out.print(mensaje);
        if (!scanner.hasNextLine()) {
            throw new FinDeEntradaException();
        }
        return scanner.nextLine().trim();
    }

    public String leerTexto(String mensaje) {
        while (true) {
            String texto = leerLinea(mensaje);
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("  Este dato es obligatorio.");
        }
    }

    public String leerTextoOpcional(String mensaje) {
        return leerLinea(mensaje);
    }

    public int leerEntero(String mensaje) {
        while (true) {
            try {
                return Integer.parseInt(leerLinea(mensaje));
            } catch (NumberFormatException e) {
                System.out.println("  Ingrese un número entero.");
            }
        }
    }

    public int leerOpcion(String mensaje, int minimo, int maximo) {
        while (true) {
            int opcion = leerEntero(mensaje);
            if (opcion >= minimo && opcion <= maximo) {
                return opcion;
            }
            System.out.println("  Opción inválida (" + minimo + " a " + maximo + ").");
        }
    }

    public double leerDecimal(String mensaje) {
        while (true) {
            try {
                return Double.parseDouble(leerLinea(mensaje).replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.println("  Ingrese un número (puede tener decimales).");
            }
        }
    }

    public boolean leerSiNo(String mensaje) {
        while (true) {
            String respuesta = leerLinea(mensaje + " (s/n): ").toLowerCase();
            if (respuesta.equals("s") || respuesta.equals("si") || respuesta.equals("sí")) {
                return true;
            }
            if (respuesta.equals("n") || respuesta.equals("no")) {
                return false;
            }
            System.out.println("  Responda s o n.");
        }
    }

    public LocalDate leerFecha(String mensaje) {
        while (true) {
            try {
                return LocalDate.parse(leerLinea(mensaje + " (dd/mm/aaaa): "), FECHA);
            } catch (DateTimeParseException e) {
                System.out.println("  Fecha inválida.");
            }
        }
    }

    public LocalDateTime leerFechaHora(String mensaje) {
        while (true) {
            try {
                return LocalDateTime.parse(leerLinea(mensaje + " (dd/mm/aaaa hh:mm): "), FECHA_HORA);
            } catch (DateTimeParseException e) {
                System.out.println("  Fecha u hora inválida.");
            }
        }
    }

    /** Si se deja vacío devuelve la fecha y hora actual. Sirve para probar cancelaciones, ausencias, etc. */
    public LocalDateTime leerFechaHoraOpcional(String mensaje) {
        while (true) {
            String texto = leerLinea(mensaje + " (dd/mm/aaaa hh:mm, Enter = ahora): ");
            if (texto.isEmpty()) {
                return LocalDateTime.now();
            }
            try {
                return LocalDateTime.parse(texto, FECHA_HORA);
            } catch (DateTimeParseException e) {
                System.out.println("  Fecha u hora inválida.");
            }
        }
    }

    public LocalTime leerHora(String mensaje) {
        while (true) {
            try {
                return LocalTime.parse(leerLinea(mensaje + " (hh:mm): "));
            } catch (DateTimeParseException e) {
                System.out.println("  Hora inválida.");
            }
        }
    }
}
