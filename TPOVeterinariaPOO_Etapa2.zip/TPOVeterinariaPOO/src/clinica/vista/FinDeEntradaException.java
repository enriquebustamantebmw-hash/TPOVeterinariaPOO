package clinica.vista;

/** Se usa cuando se termina la entrada estándar (por ejemplo, si se ejecuta con un archivo de entrada). */
public class FinDeEntradaException extends RuntimeException {
    public FinDeEntradaException() {
        super("Se terminó la entrada");
    }
}
