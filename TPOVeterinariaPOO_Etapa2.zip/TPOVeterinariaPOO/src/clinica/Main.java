package clinica;

import clinica.controladores.ControladorAdministracion;
import clinica.controladores.ControladorConsultas;
import clinica.controladores.ControladorFacturacion;
import clinica.controladores.ControladorMascotas;
import clinica.controladores.ControladorTurnos;
import clinica.excepciones.PersistenciaException;
import clinica.persistencia.ArchivoDatos;
import clinica.persistencia.BaseDeDatos;
import clinica.persistencia.DatosIniciales;
import clinica.servicios.AlertaAdministrador;
import clinica.servicios.Notificador;
import clinica.servicios.NotificadorArchivo;
import clinica.servicios.ServicioRecordatorios;
import clinica.servicios.ServicioStock;
import clinica.vista.Consola;
import clinica.vista.MenuConsola;

import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ArchivoDatos archivo = new ArchivoDatos(Paths.get("datos", "clinica.dat"));
        BaseDeDatos base = null;
        if (archivo.existe()) {
            try {
                base = archivo.cargar();
                System.out.println("Se cargaron los datos guardados.");
            } catch (PersistenciaException e) {
                System.out.println("ERROR: " + e.getMessage() + ". Se empieza con los datos de prueba.");
            }
        }
        if (base == null) {
            base = new BaseDeDatos();
            DatosIniciales.cargar(base, LocalDate.now());
            System.out.println("Primera ejecución: se cargaron los datos de prueba.");
        }

        // acá se arman todas las dependencias; las clases solo conocen interfaces
        Notificador notificador = new NotificadorArchivo(Paths.get("datos", "notificaciones.txt"));
        ServicioStock servicioStock = new ServicioStock(base.getInsumos());
        servicioStock.suscribir(new AlertaAdministrador(notificador));
        ServicioRecordatorios recordatorios = new ServicioRecordatorios(base.getMascotas(), notificador,
                base.getRecordatoriosEnviados());

        ControladorMascotas mascotas = new ControladorMascotas(base.getDuenos(), base.getMascotas(),
                base.getPlanes(), base);
        ControladorTurnos turnos = new ControladorTurnos(base.getTurnos(), base.getDuenos(), base.getMascotas(),
                base.getEmpleados(), notificador, base);
        ControladorConsultas consultas = new ControladorConsultas(base.getMascotas(), base.getEmpleados(),
                base.getTurnos(), base.getVacunas(), servicioStock);
        ControladorFacturacion facturacion = new ControladorFacturacion(base.getFacturas(), base.getMascotas(), base);
        ControladorAdministracion administracion = new ControladorAdministracion(base.getEmpleados(),
                base.getProveedores(), servicioStock, recordatorios);

        Consola consola = new Consola(new Scanner(System.in, "UTF-8"));
        new MenuConsola(consola, archivo, base, mascotas, turnos, consultas, facturacion, administracion).iniciar();
    }
}
